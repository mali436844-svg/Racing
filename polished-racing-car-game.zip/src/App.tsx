import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDown, ChevronLeft, ChevronRight, Pause, Volume2, VolumeX, Zap } from "lucide-react";
import { GameEngine, type HudBindings, type Phase, type RunStats } from "./game/engine";
import {
  bestScore, loadLastName, loadMuted, loadScores, recordRun, renameEntry, saveLastName, type ScoreEntry,
} from "./game/storage";
import { Countdown, GameOverScreen, KeyCap, PauseScreen, StartScreen } from "./components/Overlays";

/* ---------------------------------- touch button */
function TouchButton({
  children, onHold, className = "", label,
}: {
  children: React.ReactNode;
  onHold: (down: boolean) => void;
  className?: string;
  label: string;
}) {
  const [held, setHeld] = useState(false);
  const press = (e: React.PointerEvent, down: boolean) => {
    e.preventDefault();
    if (down) {
      try {
        (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
      } catch {
        /* synthetic pointers */
      }
    }
    setHeld(down);
    onHold(down);
  };
  return (
    <button
      aria-label={label}
      onPointerDown={(e) => press(e, true)}
      onPointerUp={(e) => press(e, false)}
      onPointerCancel={(e) => press(e, false)}
      onContextMenu={(e) => e.preventDefault()}
      className={`touch-btn pointer-events-auto flex select-none flex-col items-center justify-center gap-0.5 rounded-xl border backdrop-blur-sm ${held ? "held" : ""} ${className}`}
    >
      {children}
    </button>
  );
}

/* ---------------------------------- app */
export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const hudRef = useRef<HudBindings>({});

  const [phase, setPhase] = useState<Phase>("menu");
  const [countdown, setCountdown] = useState<number | null>(null);
  const [stats, setStats] = useState<RunStats | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const [initials, setInitials] = useState(() => loadLastName());
  const [muted, setMuted] = useState(() => loadMuted());
  const [isTouch] = useState(
    () => window.matchMedia?.("(pointer: coarse)").matches || "ontouchstart" in window,
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new GameEngine(canvas, {
      onPhase: (p, s) => {
        setPhase(p);
        if (p === "gameover" && s) {
          const { scores: next, id } = recordRun({
            name: loadLastName(),
            score: s.score,
            dist: s.dist,
            topSpeed: s.topSpeed,
          });
          setScores(next);
          setHighlightId(id);
          setInitials(loadLastName());
          engine.setBest(bestScore(next));
          setStats(s);
        }
      },
      onCountdown: (n) => setCountdown(n === -1 ? null : n),
      onMuted: setMuted,
    });
    engine.bindHud(hudRef.current);
    engine.setBest(bestScore(loadScores()));
    engine.setTouchMode(isTouch);
    engineRef.current = engine;
    (window as any).__APEX__ = engine; // debug/testing handle
    return () => {
      engine.destroy();
      engineRef.current = null;
      delete (window as any).__APEX__;
    };
  }, []);

  const start = useCallback(() => engineRef.current?.startRun(), []);
  const restart = useCallback(() => engineRef.current?.restart(), []);
  const resume = useCallback(() => engineRef.current?.resume(), []);
  const pauseGame = useCallback(() => engineRef.current?.pause(), []);
  const toMenu = useCallback(() => engineRef.current?.toMenu(), []);
  const toggleMute = useCallback(() => engineRef.current?.toggleMute(), []);
  const hold = useCallback(
    (key: "left" | "right" | "brake" | "nitro") => (down: boolean) => engineRef.current?.setInput(key, down),
    [],
  );

  const onInitials = useCallback(
    (v: string) => {
      setInitials(v);
      const name = v || "AAA";
      saveLastName(name);
      if (highlightId) setScores(renameEntry(highlightId, name));
    },
    [highlightId],
  );

  const inGame = phase === "countdown" || phase === "playing" || phase === "paused" || phase === "crashing";
  const showTouch = isTouch && (phase === "countdown" || phase === "playing");

  return (
    <div className="fixed inset-0 overflow-hidden bg-pit font-body text-cream">
      <canvas ref={canvasRef} className="absolute inset-0 z-0" />
      <div className="scanlines absolute inset-0 z-[5]" />
      <div className="vignette absolute inset-0 z-[6]" />

      {/* ------------ HUD (updated imperatively at 60fps) ------------ */}
      <div className={`pointer-events-none absolute inset-0 z-10 transition-opacity duration-300 ${inGame ? "opacity-100" : "opacity-0"}`}>
        {/* top bar */}
        <div
          className="flex items-start justify-between p-3 sm:p-5"
          style={{
            paddingLeft: "max(0.75rem, env(safe-area-inset-left))",
            paddingRight: "max(0.75rem, env(safe-area-inset-right))",
          }}
        >
          <div>
            <div className="hud-label text-[10px] text-cream/60">SCORE</div>
            <div ref={(el) => { hudRef.current.score = el; }} className="hud-num text-3xl leading-none text-cream sm:text-4xl">0</div>
            <div
              ref={(el) => { hudRef.current.comboWrap = el; }}
              className="mt-1.5 w-24 rounded-sm border border-flame/40 bg-pit/60 px-1.5 py-1 opacity-0 transition-opacity"
            >
              <div className="flex items-center gap-1 text-flame">
                <Zap className="h-3 w-3" />
                <span className="font-display text-[10px] tracking-wider">COMBO</span>
                <span ref={(el) => { hudRef.current.combo = el; }} className="hud-num ml-auto text-sm">×2</span>
              </div>
              <div className="mt-1 h-0.5 overflow-hidden rounded bg-pit">
                <div ref={(el) => { hudRef.current.comboBar = el; }} className="h-full w-full origin-left bg-flame" />
              </div>
            </div>
          </div>

          <div className="mt-0.5 flex flex-col items-center gap-1">
            {isTouch && (
              <div className="text-center leading-none">
                <span ref={(el) => { hudRef.current.speed = el; }} className="hud-num text-4xl text-cream">0</span>
                <span className="hud-label ml-1 text-[9px] text-cream/60">KM/H</span>
              </div>
            )}
            <div ref={(el) => { hudRef.current.dist = el; }} className="hud-num rounded-sm bg-pit/55 px-2.5 py-1 text-sm text-cream/85">0.00 km</div>
            <div ref={(el) => { hudRef.current.multWrap = el; }} className="rounded-sm bg-lagoon/20 px-2 py-0.5 font-display text-[11px] tracking-widest text-lagoon opacity-0 transition-opacity">
              NITRO ×2
            </div>
          </div>

          <div className="flex flex-col items-end">
            <div className="hud-label text-[10px] text-cream/60">BEST</div>
            <div ref={(el) => { hudRef.current.best = el; }} className="hud-num text-xl leading-none text-flame sm:text-2xl">0</div>
            <div className="pointer-events-auto mt-2 flex gap-1.5">
              <button
                onClick={(e) => { toggleMute(); e.currentTarget.blur(); }}
                aria-label={muted ? "Unmute" : "Mute"}
                className="flex h-9 w-9 items-center justify-center rounded-md border border-cream/25 bg-pit/60 text-cream/85 backdrop-blur-sm transition hover:bg-dusk"
              >
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>
              <button
                onClick={(e) => { pauseGame(); e.currentTarget.blur(); }}
                aria-label="Pause"
                className="flex h-9 items-center justify-center gap-1.5 rounded-md border border-cream/25 bg-pit/60 px-2.5 text-cream/85 backdrop-blur-sm transition hover:bg-dusk"
              >
                <Pause className="h-4 w-4" />
                <span className="hidden font-display text-[10px] tracking-widest sm:inline">PAUSE</span>
              </button>
            </div>
          </div>
        </div>

        {/* speed (desktop) */}
        {!isTouch && (
          <div className="absolute bottom-5 right-4 text-right sm:right-6">
            <span ref={(el) => { hudRef.current.speed = el; }} className="hud-num text-5xl leading-none text-cream sm:text-6xl">0</span>
            <span className="hud-label ml-1 text-[10px] text-cream/60">KM/H</span>
          </div>
        )}

        {/* nitro meter */}
        <div
          className={`absolute ${isTouch ? "left-1/2 top-[7.6rem] w-44 -translate-x-1/2" : "bottom-6 left-4 w-48 sm:left-6 sm:w-64 md:bottom-14"}`}
          style={isTouch ? undefined : { paddingLeft: "env(safe-area-inset-left)" }}
        >
          <div
            ref={(el) => { hudRef.current.nitroWrap = el; }}
            data-state="low"
            className="rounded-md border border-lagoon/40 bg-pit/65 px-2.5 py-1.5 backdrop-blur-sm data-[state=active]:border-lagoon data-[state=active]:bg-lagoon/15"
          >
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1 text-lagoon">
                <Zap className="h-3 w-3" />
                <span ref={(el) => { hudRef.current.nitroLabel = el; }} className="font-display text-[9px] tracking-[0.2em]">NITRO</span>
              </span>
              {!isTouch && <KeyCap>SPACE</KeyCap>}
            </div>
            <div className="mt-1 h-2 overflow-hidden rounded-sm bg-pit/90" style={{ transform: "skewX(-12deg)" }}>
              <div
                ref={(el) => { hudRef.current.nitroFill = el; }}
                className="h-full w-full origin-left bg-gradient-to-r from-lagoon/70 to-lagoon"
                style={{ transform: "scaleX(0.4)" }}
              />
            </div>
          </div>
        </div>

        {/* desktop key hints */}
        {!isTouch && (
          <div className="absolute bottom-5 left-5 hidden items-center gap-2 text-[11px] text-cream/55 md:flex">
            <KeyCap>◀</KeyCap><KeyCap>▶</KeyCap> steer
            <KeyCap>▼</KeyCap> brake
            <KeyCap>P</KeyCap> pause
            <KeyCap>R</KeyCap> restart
          </div>
        )}
      </div>

      {/* ------------ touch controls ------------ */}
      {showTouch && (
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex items-end justify-between p-4 pb-[max(1rem,env(safe-area-inset-bottom))]"
          style={{
            paddingLeft: "max(1rem, env(safe-area-inset-left))",
            paddingRight: "max(1rem, env(safe-area-inset-right))",
          }}
        >
          <div className="flex gap-3">
            <TouchButton label="Steer left" onHold={hold("left")} className="h-20 w-20 border-cream/25 bg-dusk/70 text-cream active:bg-lagoon/25 sm:h-24 sm:w-24">
              <ChevronLeft className="h-10 w-10" />
            </TouchButton>
            <TouchButton label="Steer right" onHold={hold("right")} className="h-20 w-20 border-cream/25 bg-dusk/70 text-cream active:bg-lagoon/25 sm:h-24 sm:w-24">
              <ChevronRight className="h-10 w-10" />
            </TouchButton>
          </div>
          <div className="flex items-end gap-3">
            <TouchButton label="Brake" onHold={hold("brake")} className="h-16 w-16 border-ember/50 bg-ember/20 text-ember sm:h-20 sm:w-20">
              <ArrowDown className="h-6 w-6" />
              <span className="font-display text-[8px] tracking-widest">BRAKE</span>
            </TouchButton>
            <TouchButton label="Nitro boost" onHold={hold("nitro")} className="h-20 w-24 border-lagoon/60 bg-lagoon/25 text-lagoon sm:h-24 sm:w-28">
              <Zap className="h-8 w-8 fill-current" />
              <span className="font-display text-[9px] tracking-widest">NITRO</span>
            </TouchButton>
          </div>
        </div>
      )}

      {/* ------------ overlays ------------ */}
      {countdown !== null && (phase === "countdown" || phase === "playing") && <Countdown value={countdown} />}
      {phase === "menu" && (
        <StartScreen scores={scores} muted={muted} isTouch={isTouch} onStart={start} onToggleMute={toggleMute} />
      )}
      {phase === "paused" && (
        <PauseScreen muted={muted} onResume={resume} onRestart={restart} onMenu={toMenu} onToggleMute={toggleMute} />
      )}
      {phase === "gameover" && stats && (
        <GameOverScreen
          stats={stats}
          scores={scores}
          highlightId={highlightId}
          initials={initials}
          isTouch={isTouch}
          onInitials={onInitials}
          onRestart={restart}
          onMenu={toMenu}
        />
      )}
    </div>
  );
}