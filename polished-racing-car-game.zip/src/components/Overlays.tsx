import { Crown, Flag, Gauge, Home, Pause, Play, RotateCcw, Trophy, Volume2, VolumeX, Zap } from "lucide-react";
import type { RunStats } from "../game/engine";
import type { ScoreEntry } from "../game/storage";

/* ---------------------------------- shared bits */
export function KeyCap({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="inline-flex min-w-6 items-center justify-center rounded border border-cream/30 bg-pit/80 px-1.5 py-0.5 font-body text-[11px] font-semibold text-cream shadow-[0_2px_0_rgba(0,0,0,0.6)]">
      {children}
    </kbd>
  );
}

function ControlRow({ keys, label }: { keys: string[]; label: string }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1">
      <span className="text-[13px] text-cream/75">{label}</span>
      <span className="flex gap-1">
        {keys.map((k) => (
          <KeyCap key={k}>{k}</KeyCap>
        ))}
      </span>
    </div>
  );
}

export function ScoreTable({ scores, highlightId }: { scores: ScoreEntry[]; highlightId?: string | null }) {
  if (scores.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 py-6 text-center">
        <Flag className="h-7 w-7 text-flame" />
        <p className="text-sm text-cream/70">No laps logged yet.</p>
        <p className="text-xs text-cream/45">Set the first track record!</p>
      </div>
    );
  }
  return (
    <ol className="flex flex-col gap-1">
      {scores.map((s, i) => (
        <li
          key={s.id}
          className={`flex items-center gap-2.5 rounded-sm px-2.5 py-1.5 ${
            s.id === highlightId ? "border-l-2 border-ember bg-ember/15" : "border-l-2 border-transparent odd:bg-cream/[0.04]"
          }`}
        >
          <span className="w-5 text-center">
            {i === 0 ? <Crown className="mx-auto h-4 w-4 text-flame" /> : <span className="font-display text-xs text-cream/50">{i + 1}</span>}
          </span>
          <span className="font-display text-sm tracking-widest text-cream">{s.name}</span>
          {s.id === highlightId && <span className="rounded-sm bg-ember px-1 text-[9px] font-bold text-pit">NEW</span>}
          <span className="ml-auto text-right">
            <span className="hud-num block text-sm text-flame">{s.score.toLocaleString("en-US")}</span>
            <span className="block text-[10px] leading-tight text-cream/45">{(s.dist / 1000).toFixed(1)} km · {s.topSpeed} km/h</span>
          </span>
        </li>
      ))}
    </ol>
  );
}

function PanelHeader({ title }: { title: string }) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <Trophy className="h-4 w-4 text-flame" />
      <h3 className="font-display text-xs tracking-[0.25em] text-cream/85">{title}</h3>
      <div className="checker ml-auto h-2.5 w-16 opacity-60" />
    </div>
  );
}

/* ---------------------------------- start screen */
export function StartScreen({
  scores, muted, isTouch, onStart, onToggleMute,
}: {
  scores: ScoreEntry[];
  muted: boolean;
  isTouch: boolean;
  onStart: () => void;
  onToggleMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-pit/45 p-3 backdrop-blur-[2px] sm:p-6">
      <div className="panel-race anim-rise relative max-h-[94dvh] w-full max-w-3xl overflow-y-auto p-5 sm:p-8">
        <div className="checker absolute inset-x-0 top-0 h-2.5 opacity-80" />
        <div className="mb-1 mt-2 flex items-center gap-2 text-flame">
          <Flag className="anim-flag h-4 w-4" />
          <span className="text-[11px] font-semibold tracking-[0.3em]">SUNSET CIRCUIT · ARCADE RACER</span>
          <button
            onClick={(e) => { onToggleMute(); e.currentTarget.blur(); }}
            className="ml-auto flex h-8 w-8 items-center justify-center rounded-sm border border-cream/20 bg-pit/60 text-cream/80 transition hover:text-cream"
            aria-label={muted ? "Unmute sound" : "Mute sound"}
          >
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </button>
        </div>
        <h1 className="logo-apex text-6xl leading-none sm:text-7xl">
          APEX<span className="text-flame">RUSH</span>
        </h1>
        <p className="mt-2 text-sm text-cream/75">
          Outrun the dusk. <span className="text-lagoon">Skim traffic</span> to charge nitro, chain near-misses, and don't lift.
        </p>

        <div className="mt-5 grid gap-5 sm:grid-cols-[1.15fr_1fr]">
          <div className="anim-rise-1">
            <button onClick={(e) => { onStart(); e.currentTarget.blur(); }} className="btn-race btn-primary w-full px-6 py-4 text-xl">
              <span className="flex items-center justify-center gap-2.5">
                <Play className="h-5 w-5 fill-current" /> START ENGINE
              </span>
            </button>
            {!isTouch && (
              <p className="anim-blink mt-2 text-center text-[11px] tracking-[0.25em] text-cream/60">
                PRESS <span className="text-flame">ENTER</span> TO RACE
              </p>
            )}

            <div className="mt-4 rounded-sm border border-cream/12 bg-pit/50 p-3.5">
              <h3 className="mb-1.5 font-display text-xs tracking-[0.25em] text-lagoon">
                {isTouch ? "TOUCH CONTROLS" : "CONTROLS"}
              </h3>
              {isTouch ? (
                <ul className="space-y-1.5 text-[13px] text-cream/75">
                  <li>◀ ▶ pads — steer between lanes</li>
                  <li><span className="text-lagoon">NITRO</span> button — hold to boost (×2 score)</li>
                  <li><span className="text-ember">BRAKE</span> button — scrub speed for tight gaps</li>
                  <li>Throttle is automatic. Survive the traffic!</li>
                </ul>
              ) : (
                <>
                  <ControlRow keys={["◀", "▶", "A", "D"]} label="Steer" />
                  <ControlRow keys={["▼", "S"]} label="Brake" />
                  <ControlRow keys={["SPACE", "SHIFT"]} label="Nitro boost" />
                  <ControlRow keys={["P", "ESC"]} label="Pause" />
                  <ControlRow keys={["R"]} label="Instant restart" />
                </>
              )}
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5 text-[10px] font-semibold tracking-wider">
              <span className="rounded-sm bg-lagoon/15 px-2 py-1 text-lagoon">NEAR MISS +150 × COMBO</span>
              <span className="rounded-sm bg-flame/15 px-2 py-1 text-flame">NITRO ×2 SCORE</span>
              <span className="rounded-sm bg-cream/10 px-2 py-1 text-cream/70">+500 / KM</span>
            </div>
          </div>

          <div className="anim-rise-2 rounded-sm border border-cream/12 bg-pit/50 p-3.5">
            <PanelHeader title="LOCAL LEADERBOARD" />
            <ScoreTable scores={scores} />
            <p className="mt-3 text-center text-[10px] tracking-wider text-cream/40">TOP 5 RUNS · SAVED ON THIS DEVICE</p>
          </div>
        </div>

        <div className="mt-5 overflow-hidden border-t border-cream/10 pt-2.5">
          <div className="anim-marquee flex w-max whitespace-nowrap text-[10px] tracking-[0.3em] text-cream/35">
            {[0, 1].map((i) => (
              <span key={i} className="pr-8">
                WEAVE THROUGH TRAFFIC ✦ SKIM CARS FOR NITRO ✦ ONE HIT AND YOU'RE SCRAP ✦ BRAKE IS A WEAPON ✦ CHASE THE SUNSET ✦&nbsp;
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- pause */
export function PauseScreen({
  muted, onResume, onRestart, onMenu, onToggleMute,
}: {
  muted: boolean;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  onToggleMute: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-pit/70 p-4 backdrop-blur-sm">
      <div className="panel-race anim-rise w-full max-w-sm p-6 text-center">
        <Pause className="mx-auto h-9 w-9 text-flame" />
        <h2 className="logo-apex mt-1 text-4xl">PAUSED</h2>
        <p className="mt-1 text-xs tracking-[0.2em] text-cream/55">ENGINE IDLING IN THE PIT LANE</p>
        <div className="mt-5 flex flex-col gap-2.5">
          <button onClick={(e) => { onResume(); e.currentTarget.blur(); }} className="btn-race btn-primary px-5 py-3 text-base">
            <span className="flex items-center justify-center gap-2"><Play className="h-4 w-4 fill-current" /> RESUME</span>
          </button>
          <button onClick={(e) => { onRestart(); e.currentTarget.blur(); }} className="btn-race btn-ghost px-5 py-2.5 text-sm">
            <span className="flex items-center justify-center gap-2"><RotateCcw className="h-4 w-4" /> RESTART RUN</span>
          </button>
          <div className="flex gap-2.5">
            <button onClick={(e) => { onMenu(); e.currentTarget.blur(); }} className="btn-race btn-ghost flex-1 px-4 py-2.5 text-sm">
              <span className="flex items-center justify-center gap-2"><Home className="h-4 w-4" /> MENU</span>
            </button>
            <button onClick={(e) => { onToggleMute(); e.currentTarget.blur(); }} className="btn-race btn-ghost flex-1 px-4 py-2.5 text-sm">
              <span className="flex items-center justify-center gap-2">
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />} {muted ? "UNMUTE" : "MUTE"}
              </span>
            </button>
          </div>
        </div>
        <p className="mt-4 text-[11px] text-cream/50">
          <KeyCap>P</KeyCap> resume · <KeyCap>R</KeyCap> restart · <KeyCap>M</KeyCap> sound
        </p>
      </div>
    </div>
  );
}

/* ---------------------------------- game over */
function StatTile({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-sm border border-cream/12 bg-pit/55 px-2 py-2.5 text-center">
      <div className="mx-auto mb-1 flex h-4 w-4 items-center justify-center text-lagoon">{icon}</div>
      <div className="hud-num text-base text-cream">{value}</div>
      <div className="hud-label mt-0.5 text-[9px] text-cream/50">{label}</div>
    </div>
  );
}

export function GameOverScreen({
  stats, scores, highlightId, initials, isTouch, onInitials, onRestart, onMenu,
}: {
  stats: RunStats;
  scores: ScoreEntry[];
  highlightId: string | null;
  initials: string;
  isTouch: boolean;
  onInitials: (v: string) => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-pit/60 p-3 backdrop-blur-[3px] sm:p-6">
      <div className="panel-race anim-rise max-h-[94dvh] w-full max-w-2xl overflow-y-auto p-5 sm:p-7">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="logo-apex text-5xl text-danger sm:text-6xl" style={{ textShadow: "0.045em 0.045em 0 #5c0f08, 0 0 34px rgba(255,68,56,0.4)" }}>
              WRECKED
            </h2>
            <p className="mt-1 text-xs tracking-[0.25em] text-cream/55">THE DUSK CLAIMS ANOTHER RACER</p>
          </div>
          <div className="text-right">
            <div className="hud-label text-[10px] text-cream/55">FINAL SCORE</div>
            <div className="hud-num text-4xl text-flame sm:text-5xl">{stats.score.toLocaleString("en-US")}</div>
            {stats.isRecord ? (
              <div className="anim-record mt-0.5 flex items-center justify-end gap-1 font-display text-xs tracking-widest">
                <Crown className="h-3.5 w-3.5 text-flame" /> NEW RECORD
              </div>
            ) : (
              <div className="mt-0.5 text-[11px] text-cream/50">BEST {stats.best.toLocaleString("en-US")}</div>
            )}
          </div>
        </div>

        <div className="anim-rise-1 mt-4 grid grid-cols-3 gap-2">
          <StatTile icon={<Gauge className="h-4 w-4" />} label="TOP SPEED" value={`${stats.topSpeed} km/h`} />
          <StatTile icon={<Flag className="h-4 w-4" />} label="DISTANCE" value={`${(stats.dist / 1000).toFixed(2)} km`} />
          <StatTile icon={<Zap className="h-4 w-4" />} label="NEAR MISSES" value={String(stats.nearMisses)} />
        </div>

        <div className="mt-4 grid gap-4 sm:grid-cols-[1fr_1.1fr]">
          <div className="anim-rise-2 flex flex-col gap-2.5">
            {highlightId && (
              <div className="rounded-sm border border-flame/30 bg-flame/10 p-3 text-center">
                <p className="font-display text-[11px] tracking-[0.2em] text-flame">TOP 5 FINISH — SIGN YOUR RUN</p>
                <input
                  value={initials}
                  onChange={(e) => onInitials(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 3))}
                  onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
                  maxLength={3}
                  autoFocus={!isTouch}
                  aria-label="Your initials"
                  className="mt-2 w-28 rounded-sm border border-cream/30 bg-pit/80 px-2 py-1.5 text-center font-display text-2xl tracking-[0.4em] text-cream outline-none focus:border-lagoon"
                />
              </div>
            )}
            <button onClick={(e) => { onRestart(); e.currentTarget.blur(); }} className="btn-race btn-primary w-full px-5 py-3.5 text-lg">
              <span className="flex items-center justify-center gap-2"><RotateCcw className="h-5 w-5" /> RACE AGAIN</span>
            </button>
            {!isTouch && (
              <p className="anim-blink -mt-1 text-center text-[10px] tracking-[0.25em] text-cream/55">
                <span className="text-flame">R</span> OR <span className="text-flame">ENTER</span> — INSTANT RESTART
              </p>
            )}
            <button onClick={(e) => { onMenu(); e.currentTarget.blur(); }} className="btn-race btn-ghost w-full px-5 py-2.5 text-sm">
              <span className="flex items-center justify-center gap-2"><Home className="h-4 w-4" /> BACK TO MENU</span>
            </button>
          </div>
          <div className="anim-rise-3 rounded-sm border border-cream/12 bg-pit/50 p-3.5">
            <PanelHeader title="LOCAL LEADERBOARD" />
            <ScoreTable scores={scores} highlightId={highlightId} />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- countdown */
export function Countdown({ value }: { value: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
      <div
        key={value}
        className={`anim-cd logo-apex text-[26vmin] leading-none ${value === 0 ? "text-lagoon" : "text-cream"}`}
        style={value === 0 ? { textShadow: "0.045em 0.045em 0 #0a5d53, 0 0 50px rgba(63,232,210,0.6)" } : undefined}
      >
        {value === 0 ? "GO!" : value}
      </div>
    </div>
  );
}