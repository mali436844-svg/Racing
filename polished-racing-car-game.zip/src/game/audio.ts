/** Fully synthesized WebAudio soundscape — no assets needed. */
export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;

  private engOsc1: OscillatorNode | null = null;
  private engOsc2: OscillatorNode | null = null;
  private engFilter: BiquadFilterNode | null = null;
  private engGain: GainNode | null = null;
  private windSrc: AudioBufferSourceNode | null = null;
  private windFilter: BiquadFilterNode | null = null;
  private windGain: GainNode | null = null;
  private rumbleGain: GainNode | null = null;
  private nitroGain: GainNode | null = null;

  muted = false;

  /** Must be called from a user gesture. Safe to call repeatedly. */
  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
      return;
    }
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      const ctx: AudioContext = new AC();
      this.ctx = ctx;

      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -16;
      comp.ratio.value = 8;
      comp.connect(ctx.destination);
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(comp);

      // white noise buffer
      const buf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      this.noiseBuf = buf;

      // engine: two detuned saws through a lowpass
      this.engGain = ctx.createGain();
      this.engGain.gain.value = 0;
      this.engFilter = ctx.createBiquadFilter();
      this.engFilter.type = "lowpass";
      this.engFilter.frequency.value = 500;
      this.engOsc1 = ctx.createOscillator();
      this.engOsc1.type = "sawtooth";
      this.engOsc2 = ctx.createOscillator();
      this.engOsc2.type = "square";
      this.engOsc1.connect(this.engFilter);
      this.engOsc2.connect(this.engFilter);
      this.engFilter.connect(this.engGain);
      this.engGain.connect(this.master);
      this.engOsc1.start();
      this.engOsc2.start();

      // wind
      this.windSrc = ctx.createBufferSource();
      this.windSrc.buffer = buf;
      this.windSrc.loop = true;
      this.windFilter = ctx.createBiquadFilter();
      this.windFilter.type = "bandpass";
      this.windFilter.Q.value = 0.5;
      this.windGain = ctx.createGain();
      this.windGain.gain.value = 0;
      this.windSrc.connect(this.windFilter);
      this.windFilter.connect(this.windGain);
      this.windGain.connect(this.master);
      this.windSrc.start();

      // offroad rumble (lowpassed noise)
      const rumbleSrc = ctx.createBufferSource();
      rumbleSrc.buffer = buf;
      rumbleSrc.loop = true;
      const rf = ctx.createBiquadFilter();
      rf.type = "lowpass";
      rf.frequency.value = 140;
      this.rumbleGain = ctx.createGain();
      this.rumbleGain.gain.value = 0;
      rumbleSrc.connect(rf);
      rf.connect(this.rumbleGain);
      this.rumbleGain.connect(this.master);
      rumbleSrc.start();

      // nitro jet (highpassed noise)
      const nSrc = ctx.createBufferSource();
      nSrc.buffer = buf;
      nSrc.loop = true;
      const nf = ctx.createBiquadFilter();
      nf.type = "highpass";
      nf.frequency.value = 2400;
      this.nitroGain = ctx.createGain();
      this.nitroGain.gain.value = 0;
      nSrc.connect(nf);
      nf.connect(this.nitroGain);
      this.nitroGain.connect(this.master);
      nSrc.start();
    } catch {
      this.ctx = null;
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx && this.master) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.03);
    }
  }

  /** Called every frame with driving state. */
  updateEngine(speedPct: number, nitro: boolean, offroad: boolean, running: boolean) {
    if (!this.ctx || !this.engOsc1 || !this.engOsc2 || !this.engGain || !this.engFilter) return;
    const t = this.ctx.currentTime;
    const gear = (speedPct * 4) % 1;
    const rpm = 0.25 + gear * 0.75;
    const base = 52 + rpm * 78 + speedPct * 55 + (nitro ? 34 : 0);
    this.engOsc1.frequency.setTargetAtTime(base, t, 0.05);
    this.engOsc2.frequency.setTargetAtTime(base * 0.5 + 3, t, 0.05);
    this.engFilter.frequency.setTargetAtTime(380 + speedPct * 2300 + (nitro ? 900 : 0), t, 0.08);
    this.engGain.gain.setTargetAtTime(running ? 0.045 + speedPct * 0.05 : 0, t, 0.09);
    this.windFilter?.frequency.setTargetAtTime(600 + speedPct * 1100, t, 0.1);
    this.windGain?.gain.setTargetAtTime(running ? speedPct * speedPct * 0.13 : 0, t, 0.12);
    this.rumbleGain?.gain.setTargetAtTime(running && offroad ? 0.16 : 0, t, 0.05);
    this.nitroGain?.gain.setTargetAtTime(running && nitro ? 0.09 : 0, t, 0.06);
  }

  private blip(freq: number, dur: number, type: OscillatorType, gain: number, when = 0, slideTo?: number) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + when;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noiseBurst(dur: number, gain: number, from: number, to: number, type: BiquadFilterType = "bandpass") {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(from, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(30, to), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t);
    src.stop(t + dur + 0.02);
  }

  uiClick() {
    this.blip(720, 0.05, "square", 0.07);
  }
  countBeep() {
    this.blip(440, 0.11, "square", 0.16);
  }
  goBeep() {
    this.blip(880, 0.3, "square", 0.18);
    this.blip(1318, 0.3, "square", 0.1, 0.02);
  }
  nearMiss(combo: number) {
    this.noiseBurst(0.18, 0.3, 500, 3400);
    const f = 620 * Math.pow(1.09, Math.min(combo, 9));
    this.blip(f, 0.07, "sine", 0.14, 0.02);
    this.blip(f * 1.5, 0.09, "sine", 0.12, 0.08);
  }
  nitroIgnite() {
    this.noiseBurst(0.35, 0.22, 900, 4200, "highpass");
    this.blip(180, 0.3, "sawtooth", 0.12, 0, 420);
  }
  crash() {
    this.noiseBurst(0.75, 0.65, 2800, 140, "lowpass");
    this.blip(130, 0.6, "sine", 0.55, 0, 28);
    this.blip(900, 0.7, "sawtooth", 0.12, 0.05, 70);
  }
  milestone() {
    this.blip(660, 0.08, "sine", 0.12);
    this.blip(880, 0.08, "sine", 0.12, 0.08);
    this.blip(1100, 0.14, "sine", 0.12, 0.16);
  }
  record() {
    [523, 659, 784, 1046].forEach((f, i) => this.blip(f, 0.14, "square", 0.1, i * 0.09));
  }
  gameOver() {
    this.blip(300, 0.7, "sawtooth", 0.1, 0.1, 65);
  }

  dispose() {
    try {
      this.ctx?.close();
    } catch {
      /* noop */
    }
    this.ctx = null;
  }
}