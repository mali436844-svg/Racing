/** Pre-rendered vector sprites (offscreen canvases) — drawn once, blitted every frame. */

export interface SpriteImg {
  img: HTMLCanvasElement;
  aspect: number; // height / width
}

function mk(w: number, h: number, scale = 1.6): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas");
  c.width = Math.round(w * scale);
  c.height = Math.round(h * scale);
  const ctx = c.getContext("2d")!;
  ctx.scale(scale, scale);
  return [c, ctx];
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.arcTo(x + w, y, x + w, y + h, rad);
  ctx.arcTo(x + w, y + h, x, y + h, rad);
  ctx.arcTo(x, y + h, x, y, rad);
  ctx.arcTo(x, y, x + w, y, rad);
  ctx.closePath();
}

function shadow(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number) {
  ctx.fillStyle = "rgba(5,8,16,0.5)";
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
}

function taillight(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, bright: boolean) {
  ctx.save();
  ctx.shadowColor = bright ? "#ff6a50" : "#ff2d1e";
  ctx.shadowBlur = bright ? 22 : 12;
  ctx.fillStyle = bright ? "#ff7a5c" : "#e02818";
  rr(ctx, x, y, w, h, h / 2);
  ctx.fill();
  if (bright) {
    ctx.fillStyle = "#ffd9c2";
    rr(ctx, x + w * 0.15, y + h * 0.25, w * 0.7, h * 0.5, h / 4);
    ctx.fill();
  }
  ctx.restore();
}

/* ------------------------------------------------ player car */
export function makePlayerCar(brake: boolean): SpriteImg {
  const W = 300, H = 176;
  const [c, ctx] = mk(W, H);
  shadow(ctx, 150, 165, 132, 12);
  // wheels
  ctx.fillStyle = "#0c0f16";
  rr(ctx, 22, 128, 46, 36, 7); ctx.fill();
  rr(ctx, 232, 128, 46, 36, 7); ctx.fill();
  // body
  const body = ctx.createLinearGradient(0, 92, 0, 160);
  body.addColorStop(0, "#ff7a4d");
  body.addColorStop(0.45, "#ef4526");
  body.addColorStop(1, "#a81f0e");
  ctx.fillStyle = body;
  rr(ctx, 26, 100, 248, 62, 15); ctx.fill();
  // rear deck
  ctx.fillStyle = "#d63318";
  ctx.beginPath();
  ctx.moveTo(44, 104); ctx.lineTo(256, 104); ctx.lineTo(238, 66); ctx.lineTo(62, 66);
  ctx.closePath(); ctx.fill();
  // cabin / rear window
  const glass = ctx.createLinearGradient(0, 40, 0, 84);
  glass.addColorStop(0, "#4b7694");
  glass.addColorStop(0.4, "#1b3348");
  glass.addColorStop(1, "#0a1522");
  ctx.fillStyle = glass;
  ctx.beginPath();
  ctx.moveTo(76, 82); ctx.lineTo(224, 82); ctx.lineTo(208, 42); ctx.lineTo(92, 42);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#c22a12";
  rr(ctx, 86, 34, 128, 12, 6); ctx.fill();
  // cream racing stripes
  ctx.fillStyle = "#f4e7cd";
  ctx.fillRect(134, 42, 12, 40);
  ctx.fillRect(154, 42, 12, 40);
  ctx.fillRect(130, 100, 14, 46);
  ctx.fillRect(156, 100, 14, 46);
  // spoiler
  ctx.fillStyle = "#7d1608";
  ctx.fillRect(58, 58, 10, 18);
  ctx.fillRect(232, 58, 10, 18);
  const wing = ctx.createLinearGradient(0, 48, 0, 62);
  wing.addColorStop(0, "#ff8a5c");
  wing.addColorStop(1, "#b32310");
  ctx.fillStyle = wing;
  rr(ctx, 38, 48, 224, 13, 6); ctx.fill();
  // taillight bar
  taillight(ctx, 42, 112, 216, 11, brake);
  // plate
  ctx.fillStyle = "#f4e7cd";
  rr(ctx, 128, 130, 44, 15, 3); ctx.fill();
  ctx.fillStyle = "#141b2a";
  ctx.font = "bold 10px 'Chakra Petch', monospace";
  ctx.textAlign = "center";
  ctx.fillText("APEX", 150, 141);
  // diffuser + exhausts
  ctx.fillStyle = "#0c0f16";
  rr(ctx, 58, 148, 184, 15, 6); ctx.fill();
  ctx.fillStyle = "#2a303e";
  ctx.beginPath(); ctx.arc(96, 155, 6, 0, Math.PI * 2); ctx.arc(204, 155, 6, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#0a0d13";
  ctx.beginPath(); ctx.arc(96, 155, 3.4, 0, Math.PI * 2); ctx.arc(204, 155, 3.4, 0, Math.PI * 2); ctx.fill();
  return { img: c, aspect: H / W };
}

/* ------------------------------------------------ traffic */
export type TrafficKind = "sedan" | "sport" | "truck";
export interface TrafficSprite extends SpriteImg {
  worldW: number;
  kind: TrafficKind;
}

function makeSedan(color: string, dark: string): SpriteImg {
  const W = 300, H = 176;
  const [c, ctx] = mk(W, H);
  shadow(ctx, 150, 165, 126, 12);
  ctx.fillStyle = "#0c0f16";
  rr(ctx, 30, 128, 42, 34, 7); ctx.fill();
  rr(ctx, 228, 128, 42, 34, 7); ctx.fill();
  const body = ctx.createLinearGradient(0, 86, 0, 158);
  body.addColorStop(0, color);
  body.addColorStop(1, dark);
  ctx.fillStyle = body;
  rr(ctx, 32, 96, 236, 62, 14); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(52, 100); ctx.lineTo(248, 100); ctx.lineTo(228, 46); ctx.lineTo(72, 46);
  ctx.closePath(); ctx.fill();
  const glass = ctx.createLinearGradient(0, 50, 0, 92);
  glass.addColorStop(0, "#41637e");
  glass.addColorStop(1, "#0b1622");
  ctx.fillStyle = glass;
  ctx.beginPath();
  ctx.moveTo(74, 92); ctx.lineTo(226, 92); ctx.lineTo(212, 54); ctx.lineTo(88, 54);
  ctx.closePath(); ctx.fill();
  taillight(ctx, 44, 108, 52, 11, false);
  taillight(ctx, 204, 108, 52, 11, false);
  ctx.fillStyle = "#e9dfc6";
  rr(ctx, 128, 126, 44, 14, 3); ctx.fill();
  ctx.fillStyle = "rgba(8,10,18,0.55)";
  rr(ctx, 40, 144, 220, 12, 6); ctx.fill();
  return { img: c, aspect: H / W };
}

function makeSport(color: string, dark: string): SpriteImg {
  const W = 300, H = 170;
  const [c, ctx] = mk(W, H);
  shadow(ctx, 150, 160, 130, 11);
  ctx.fillStyle = "#0c0f16";
  rr(ctx, 24, 124, 46, 34, 7); ctx.fill();
  rr(ctx, 230, 124, 46, 34, 7); ctx.fill();
  const body = ctx.createLinearGradient(0, 88, 0, 154);
  body.addColorStop(0, color);
  body.addColorStop(1, dark);
  ctx.fillStyle = body;
  rr(ctx, 26, 100, 248, 54, 16); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(50, 104); ctx.lineTo(250, 104); ctx.lineTo(226, 62); ctx.lineTo(74, 62);
  ctx.closePath(); ctx.fill();
  const glass = ctx.createLinearGradient(0, 64, 0, 96);
  glass.addColorStop(0, "#4b7694");
  glass.addColorStop(1, "#0a1522");
  ctx.fillStyle = glass;
  ctx.beginPath();
  ctx.moveTo(84, 96); ctx.lineTo(216, 96); ctx.lineTo(202, 68); ctx.lineTo(98, 68);
  ctx.closePath(); ctx.fill();
  taillight(ctx, 40, 110, 76, 9, false);
  taillight(ctx, 184, 110, 76, 9, false);
  ctx.fillStyle = "rgba(8,10,18,0.55)";
  rr(ctx, 52, 140, 196, 13, 6); ctx.fill();
  return { img: c, aspect: H / W };
}

function makeTruck(color: string, dark: string): SpriteImg {
  const W = 300, H = 232;
  const [c, ctx] = mk(W, H);
  shadow(ctx, 150, 221, 132, 12);
  ctx.fillStyle = "#0c0f16";
  rr(ctx, 34, 184, 44, 36, 6); ctx.fill();
  rr(ctx, 222, 184, 44, 36, 6); ctx.fill();
  const box = ctx.createLinearGradient(0, 20, 0, 200);
  box.addColorStop(0, color);
  box.addColorStop(1, dark);
  ctx.fillStyle = box;
  rr(ctx, 34, 22, 232, 172, 8); ctx.fill();
  ctx.strokeStyle = "rgba(8,12,20,0.35)";
  ctx.lineWidth = 3;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(34 + i * 58, 28); ctx.lineTo(34 + i * 58, 188); ctx.stroke();
  }
  ctx.fillStyle = "rgba(244,231,205,0.85)";
  ctx.font = "bold 24px 'Russo One', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("APEX", 150, 96);
  ctx.font = "bold 15px 'Chakra Petch', monospace";
  ctx.fillText("FREIGHT CO.", 150, 120);
  ctx.fillStyle = "#1a212e";
  rr(ctx, 34, 192, 232, 16, 4); ctx.fill();
  taillight(ctx, 44, 194, 40, 10, false);
  taillight(ctx, 216, 194, 40, 10, false);
  return { img: c, aspect: H / W };
}

export function makeTrafficSet(): TrafficSprite[] {
  const defs: Array<[TrafficKind, string, string, number]> = [
    ["sedan", "#2fa8a2", "#14554f", 640],
    ["sedan", "#e8dcc0", "#8f825f", 640],
    ["sedan", "#e0a33c", "#8a5a14", 640],
    ["sedan", "#4a6fa5", "#22375c", 640],
    ["sedan", "#8a5a8c", "#46284a", 640],
    ["sport", "#ffd23e", "#9c7410", 620],
    ["sport", "#59c9e8", "#1e6b85", 620],
    ["truck", "#b8503c", "#5f2117", 800],
    ["truck", "#3e5a52", "#1b2d28", 800],
  ];
  return defs.map(([kind, c, d, worldW]) => {
    const s = kind === "sedan" ? makeSedan(c, d) : kind === "sport" ? makeSport(c, d) : makeTruck(c, d);
    return { ...s, worldW, kind };
  });
}

/* ------------------------------------------------ roadside */
export function makePalm(seed: number): SpriteImg {
  const W = 260, H = 400;
  const [c, ctx] = mk(W, H, 1.2);
  const lean = (seed % 3 - 1) * 22;
  const topX = 130 + lean, topY = 96;
  const draw = (color: string, off: number) => {
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 15;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(130 + off, 396);
    ctx.quadraticCurveTo(126 + lean * 0.4 + off, 240, topX + off, topY);
    ctx.stroke();
    for (let i = 0; i < 7; i++) {
      const a = -Math.PI * 0.06 - (i / 6) * Math.PI * 0.9;
      const len = 96 + (i % 3) * 16;
      const ex = topX + off + Math.cos(a) * len;
      const ey = topY + Math.sin(a) * len * 0.86 + 26;
      ctx.lineWidth = 9;
      ctx.beginPath();
      ctx.moveTo(topX + off, topY);
      ctx.quadraticCurveTo(topX + off + Math.cos(a) * len * 0.55, topY + Math.sin(a) * len * 0.34 - 18, ex, ey);
      ctx.stroke();
    }
  };
  draw("rgba(196,92,58,0.5)", 3); // dusk rim light
  draw("#0d1a2b", 0);
  return { img: c, aspect: H / W };
}

export function makeCactus(): SpriteImg {
  const W = 140, H = 220;
  const [c, ctx] = mk(W, H, 1.4);
  const draw = (color: string, off: number) => {
    ctx.strokeStyle = color;
    ctx.lineCap = "round";
    ctx.lineWidth = 26;
    ctx.beginPath(); ctx.moveTo(70 + off, 214); ctx.lineTo(70 + off, 60); ctx.stroke();
    ctx.lineWidth = 17;
    ctx.beginPath(); ctx.moveTo(70 + off, 140); ctx.lineTo(32 + off, 128); ctx.lineTo(32 + off, 84); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(70 + off, 112); ctx.lineTo(108 + off, 100); ctx.lineTo(108 + off, 58); ctx.stroke();
  };
  draw("rgba(196,92,58,0.45)", 2.5);
  draw("#0d1a2b", 0);
  return { img: c, aspect: H / W };
}

export function makeBillboard(text: string, accent: string): SpriteImg {
  const W = 420, H = 300;
  const [c, ctx] = mk(W, H, 1.2);
  ctx.fillStyle = "#0d1a2b";
  ctx.fillRect(84, 160, 22, 140);
  ctx.fillRect(314, 160, 22, 140);
  ctx.fillStyle = "#101f36";
  rr(ctx, 20, 24, 380, 168, 10); ctx.fill();
  ctx.strokeStyle = "#f4e7cd";
  ctx.lineWidth = 7;
  rr(ctx, 20, 24, 380, 168, 10); ctx.stroke();
  ctx.fillStyle = accent;
  ctx.font = "44px 'Russo One', sans-serif";
  ctx.textAlign = "center";
  const words = text.split(" ");
  if (words.length > 1) {
    ctx.fillText(words[0], 210, 100);
    ctx.fillText(words.slice(1).join(" "), 210, 156);
  } else {
    ctx.fillText(text, 210, 126);
  }
  return { img: c, aspect: H / W };
}

export function makeChevron(dir: 1 | -1): SpriteImg {
  const W = 220, H = 170;
  const [c, ctx] = mk(W, H, 1.4);
  ctx.fillStyle = "#0d1a2b";
  ctx.fillRect(96, 96, 26, 74);
  ctx.fillStyle = "#131b2c";
  rr(ctx, 10, 12, 200, 92, 8); ctx.fill();
  ctx.strokeStyle = "#f4e7cd";
  ctx.lineWidth = 5;
  rr(ctx, 10, 12, 200, 92, 8); ctx.stroke();
  ctx.fillStyle = "#ffb347";
  for (let i = 0; i < 3; i++) {
    const x = 36 + i * 56;
    ctx.beginPath();
    if (dir === 1) {
      ctx.moveTo(x, 28); ctx.lineTo(x + 30, 58); ctx.lineTo(x, 88); ctx.lineTo(x + 14, 58);
    } else {
      ctx.moveTo(x + 30, 28); ctx.lineTo(x, 58); ctx.lineTo(x + 30, 88); ctx.lineTo(x + 16, 58);
    }
    ctx.closePath(); ctx.fill();
  }
  return { img: c, aspect: H / W };
}

export function makeGantry(): SpriteImg {
  const W = 900, H = 300;
  const [c, ctx] = mk(W, H, 1.1);
  ctx.fillStyle = "#101c30";
  ctx.fillRect(28, 60, 34, 240);
  ctx.fillRect(838, 60, 34, 240);
  ctx.fillStyle = "#152540";
  rr(ctx, 10, 30, 880, 84, 10); ctx.fill();
  ctx.strokeStyle = "#f4e7cd";
  ctx.lineWidth = 5;
  rr(ctx, 10, 30, 880, 84, 10); ctx.stroke();
  // checker strips
  for (let i = 0; i < 22; i++) {
    ctx.fillStyle = i % 2 ? "#f4e7cd" : "#0b1524";
    ctx.fillRect(18 + i * 39.5, 96, 39.5, 14);
  }
  ctx.fillStyle = "#ffb347";
  ctx.font = "52px 'Russo One', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("APEX RUSH", 450, 86);
  return { img: c, aspect: H / W };
}

/* ------------------------------------------------ sky pieces */
export function makeSun(radius: number): HTMLCanvasElement {
  const pad = radius * 0.7;
  const size = (radius + pad) * 2;
  const c = document.createElement("canvas");
  c.width = c.height = Math.ceil(size);
  const ctx = c.getContext("2d")!;
  const cx = size / 2, cy = size / 2;
  const glow = ctx.createRadialGradient(cx, cy, radius * 0.3, cx, cy, radius + pad);
  glow.addColorStop(0, "rgba(255,150,80,0.5)");
  glow.addColorStop(1, "rgba(255,150,80,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, size, size);
  const g = ctx.createLinearGradient(0, cy - radius, 0, cy + radius);
  g.addColorStop(0, "#fff0c2");
  g.addColorStop(0.5, "#ffc169");
  g.addColorStop(1, "#ff5c38");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.fill();
  // retro band cuts on lower half
  ctx.globalCompositeOperation = "destination-out";
  let y = cy + radius * 0.05;
  let h = 2;
  while (y < cy + radius) {
    ctx.fillRect(0, y, size, h);
    y += h + 10 + (y - cy) * 0.06;
    h += 1.7;
  }
  return c;
}

export function makeMountains(width: number, height: number, color: string, rim: string, seed: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = width;
  c.height = height;
  const ctx = c.getContext("2d")!;
  let s = seed;
  const rnd = () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
  const pts: Array<[number, number]> = [];
  const steps = 14;
  for (let i = 0; i <= steps; i++) {
    // force matching heights at both edges so the strip tiles seamlessly
    const edge = i === 0 || i === steps;
    const y = edge ? height * 0.55 : height * (0.2 + rnd() * 0.62);
    pts.push([(i / steps) * width, y]);
  }
  ctx.beginPath();
  ctx.moveTo(0, height);
  pts.forEach(([x, y]) => ctx.lineTo(x, y));
  ctx.lineTo(width, height);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = rim;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.stroke();
  return c;
}