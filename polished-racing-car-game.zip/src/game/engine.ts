import { AudioEngine } from "./audio";
import { loadMuted, saveMuted } from "./storage";
import {
  makePlayerCar, makeTrafficSet, makePalm, makeCactus, makeBillboard, makeChevron,
  makeGantry, makeSun, makeMountains, type SpriteImg, type TrafficSprite,
} from "./sprites";

/* ============================================================= types */
export type Phase = "menu" | "countdown" | "playing" | "paused" | "crashing" | "gameover";

export interface RunStats {
  score: number;
  dist: number; // meters
  topSpeed: number; // km/h
  nearMisses: number;
  best: number;
  isRecord: boolean;
}

export interface EngineCallbacks {
  onPhase: (phase: Phase, stats?: RunStats) => void;
  onCountdown: (n: number) => void; // 3,2,1,0(GO),-1(hide)
  onMuted: (muted: boolean) => void;
}

export interface HudBindings {
  score?: HTMLElement | null;
  best?: HTMLElement | null;
  speed?: HTMLElement | null;
  dist?: HTMLElement | null;
  nitroFill?: HTMLElement | null;
  nitroWrap?: HTMLElement | null;
  nitroLabel?: HTMLElement | null;
  combo?: HTMLElement | null;
  comboWrap?: HTMLElement | null;
  comboBar?: HTMLElement | null;
  multWrap?: HTMLElement | null;
}

interface Pt {
  world: { y: number; z: number };
  camera: { x: number; y: number; z: number };
  screen: { x: number; y: number; w: number; scale: number };
}
interface RoadSprite { sprite: SpriteImg; offset: number; worldW: number }
interface Car {
  z: number; offset: number; speed: number; baseSpeed: number;
  sprite: number; hitDx: number; segIdx: number; prevRel: number;
}
interface Segment {
  index: number; p1: Pt; p2: Pt; curve: number;
  sprites: RoadSprite[]; cars: Car[]; clip: number;
}
interface Particle {
  x: number; y: number; vx: number; vy: number; g: number;
  life: number; max: number; size: number; color: string; add: boolean; shrink: boolean;
}
interface Popup { x: number; y: number; text: string; color: string; size: number; life: number; max: number }

/* ============================================================= constants */
const SEG = 200;
const ROAD_W = 2200; // half width, world units
const LANES = 3;
const CAM_H = 1100;
const CAM_D = 1 / Math.tan((100 / 2) * (Math.PI / 180));
const PLAYER_Z = CAM_H * CAM_D;
const MAX_SPEED = 12000;
const NITRO_MULT = 1.3;
const PLAYER_W = 560;
const CENTRIFUGAL = 0.3;
const KMH = 0.024;
const METERS = 1 / 150;
const NEAR_MISS_DX = 0.62;
const COMBO_WINDOW = 5;

const COLORS = {
  roadA: "#2e3444", roadB: "#2a3040",
  grassA: "#12333a", grassB: "#0f2d34",
  rumbleA: "#e8e0cf", rumbleB: "#d94f3d",
  lane: "#f4e7cd", start: "#cfc7b2",
  fog: "38,36,62",
};

const QUALITY = [
  { dpr: 2, draw: 300 },
  { dpr: 1.5, draw: 220 },
  { dpr: 1, draw: 150 },
];

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
const easeInOut = (a: number, b: number, t: number) => a + (b - a) * (-Math.cos(t * Math.PI) / 2 + 0.5);

function pt(y: number, z: number): Pt {
  return { world: { y, z }, camera: { x: 0, y: 0, z: 0 }, screen: { x: 0, y: 0, w: 0, scale: 0 } };
}

/* ============================================================= engine */
export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: EngineCallbacks;
  audio = new AudioEngine();

  phase: Phase = "menu";
  private prevPhase: Phase = "menu";
  private raf = 0;
  private last = 0;
  private time = 0;

  private w = 0; private h = 0; private dpr = 1;
  private tier = 0;
  private drawDist = 300;
  private fogStops: string[] = [];

  // world
  private segments: Segment[] = [];
  private trackLen = 0;
  private cars: Car[] = [];
  private position = 0;
  private playerX = 0;
  private steer = 0;
  private speed = 0;
  private camD = CAM_D;
  private bgOffset = 0;
  private totalM = 0;
  private nextKm = 1000;
  private protection = 0;

  // run state
  private score = 0;
  best = 0;
  private recordFired = false;
  private combo = 0;
  private comboT = 0;
  private nearMisses = 0;
  private topSpeed = 0;
  private nitroMeter = 40;
  private nitroActive = false;
  private cdValue = 3;
  private cdTimer = 0;
  private cdStep = 0.55;
  private goHide = 0;
  private crashT = 0;
  private spin = 0;
  private spinDir = 1;
  private timeScale = 1;

  // fx
  private shake = 0;
  private flash = 0;
  private particles: Particle[] = [];
  private popups: Popup[] = [];
  private rays: Array<{ a: number; off: number; len: number }> = [];

  // input
  input = { left: false, right: false, brake: false, nitro: false };

  // sprites / sky
  private playerImg!: SpriteImg;
  private playerBrake!: SpriteImg;
  private trafficImgs: TrafficSprite[] = [];
  private palmImgs: SpriteImg[] = [];
  private cactusImg!: SpriteImg;
  private chevL!: SpriteImg;
  private chevR!: SpriteImg;
  private gantry!: SpriteImg;
  private billboards: Array<{ entry: RoadSprite; text: string; accent: string }> = [];
  private sky: HTMLCanvasElement | null = null;
  private mtnFar: HTMLCanvasElement;
  private mtnNear: HTMLCanvasElement;

  private hud: HudBindings = {};
  private hudCache = new Map<HTMLElement, string>();

  // fps watchdog
  private frameAcc = 0;
  private frameCnt = 0;
  private warmup = 0;

  constructor(canvas: HTMLCanvasElement, cb: EngineCallbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.cb = cb;
    this.audio.muted = loadMuted();

    const coarse = window.matchMedia?.("(pointer: coarse)").matches;
    this.tier = coarse || Math.min(window.innerWidth, window.innerHeight) < 600 ? 1 : 0;

    this.playerImg = makePlayerCar(false);
    this.playerBrake = makePlayerCar(true);
    this.trafficImgs = makeTrafficSet();
    this.palmImgs = [makePalm(1), makePalm(2), makePalm(3)];
    this.cactusImg = makeCactus();
    this.chevL = makeChevron(-1);
    this.chevR = makeChevron(1);
    this.gantry = makeGantry();
    this.mtnFar = makeMountains(1600, 260, "#232c4e", "rgba(255,140,90,0.28)", 7);
    this.mtnNear = makeMountains(1600, 300, "#161f38", "rgba(255,120,70,0.32)", 13);

    for (let i = 0; i < 16; i++) {
      this.rays.push({ a: (i / 16) * Math.PI * 2 + 0.2, off: Math.random(), len: 0.12 + Math.random() * 0.16 });
    }

    // re-render text sprites once the display font is ready
    if (document.fonts?.ready) {
      document.fonts.ready.then(() => {
        this.gantry = makeGantry();
        this.billboards.forEach((b) => {
          b.entry.sprite = makeBillboard(b.text, b.accent);
        });
        if (this.segments[4]) {
          const g = this.segments[4].sprites.find((s) => s.worldW === 5600);
          if (g) g.sprite = this.gantry;
        }
      });
    }

    this.buildTrack(Math.floor(Math.random() * 1e9));
    this.resize();
    window.addEventListener("resize", this.resize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    document.addEventListener("visibilitychange", this.onVis);

    // attract mode
    this.speed = MAX_SPEED * 0.5;
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.resize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    document.removeEventListener("visibilitychange", this.onVis);
    this.audio.dispose();
  }

  bindHud(h: HudBindings) {
    this.hud = h;
    this.hudCache.clear();
  }
  setBest(b: number) { this.best = b; }
  /** On touch layouts the car sits higher so thumb controls never cover it. */
  touchMode = false;
  setTouchMode(b: boolean) { this.touchMode = b; }
  private playerBaseY() { return this.h * (this.touchMode ? 0.87 : 0.985); }

  /* ------------------------------------------------ public control */
  startRun(fast = false) {
    this.audio.init();
    this.buildTrack(Math.floor(Math.random() * 1e9));
    this.position = 0; this.playerX = 0; this.steer = 0; this.speed = 0;
    this.totalM = 0; this.nextKm = 1000;
    this.score = 0; this.combo = 0; this.comboT = 0; this.nearMisses = 0; this.topSpeed = 0;
    this.nitroMeter = 40; this.nitroActive = false; this.recordFired = false;
    this.particles.length = 0; this.popups.length = 0;
    this.shake = 0; this.flash = 0; this.spin = 0; this.timeScale = 1;
    this.protection = 0; this.bgOffset = 0;
    this.cdValue = 3; this.cdStep = fast ? 0.42 : 0.55; this.cdTimer = this.cdStep;
    this.resetInput();
    this.setPhase("countdown");
    this.cb.onCountdown(3);
    this.audio.countBeep();
    this.writeHud();
  }
  private resetInput() {
    this.input.left = this.input.right = this.input.brake = this.input.nitro = false;
  }
  restart() { this.audio.uiClick(); this.startRun(true); }
  pause() {
    if (this.phase !== "playing" && this.phase !== "countdown") return;
    this.prevPhase = this.phase;
    this.resetInput();
    this.audio.updateEngine(0, false, false, false);
    this.setPhase("paused");
  }
  resume() {
    if (this.phase !== "paused") return;
    this.audio.init();
    this.audio.uiClick();
    this.setPhase(this.prevPhase === "countdown" ? "countdown" : "playing");
    this.last = performance.now();
  }
  togglePause() {
    if (this.phase === "paused") this.resume();
    else this.pause();
  }
  toMenu() {
    this.audio.uiClick();
    this.resetInput();
    this.speed = MAX_SPEED * 0.5;
    this.playerX = 0; this.steer = 0; this.spin = 0; this.timeScale = 1;
    this.particles.length = 0; this.popups.length = 0; this.shake = 0; this.flash = 0;
    this.setPhase("menu");
  }
  toggleMute() {
    this.audio.init();
    this.audio.setMuted(!this.audio.muted);
    saveMuted(this.audio.muted);
    this.cb.onMuted(this.audio.muted);
  }
  setInput(key: keyof GameEngine["input"], down: boolean) {
    this.input[key] = down;
  }

  private setPhase(p: Phase, stats?: RunStats) {
    this.phase = p;
    this.cb.onPhase(p, stats);
  }

  /* ------------------------------------------------ track building */
  private buildTrack(seed: number) {
    const rnd = mulberry32(seed);
    this.segments = [];
    const lastY = () => (this.segments.length ? this.segments[this.segments.length - 1].p2.world.y : 0);
    const addSeg = (curve: number, y: number) => {
      const n = this.segments.length;
      this.segments.push({
        index: n,
        p1: pt(lastY(), n * SEG),
        p2: pt(y, (n + 1) * SEG),
        curve, sprites: [], cars: [], clip: 0,
      });
    };
    const addRoad = (enter: number, hold: number, leave: number, curve: number, dy: number) => {
      const startY = lastY();
      const endY = startY + dy * SEG;
      const total = enter + hold + leave;
      for (let i = 0; i < enter; i++) addSeg(curve * (i / enter) ** 2, easeInOut(startY, endY, i / total));
      for (let i = 0; i < hold; i++) addSeg(curve, easeInOut(startY, endY, (enter + i) / total));
      for (let i = 0; i < leave; i++) addSeg(easeInOut(curve, 0, i / leave), easeInOut(startY, endY, (enter + hold + i) / total));
    };

    addRoad(50, 40, 50, 0, 0);
    addRoad(60, 60, 60, 3, 10);
    addRoad(50, 40, 50, -4, 0);
    addRoad(40, 40, 40, 0, 25);
    addRoad(40, 40, 40, 2, -20);
    addRoad(50, 50, 50, -3, 0);
    addRoad(50, 50, 50, 4, 8);
    addRoad(50, 50, 50, -4, -8);
    addRoad(70, 80, 70, 5, 0);
    addRoad(50, 50, 50, 0, -30);
    addRoad(60, 60, 60, -5, 15);
    addRoad(40, 60, 40, 2, 0);
    addRoad(60, 40, 60, 0, -lastY() / SEG);
    this.trackLen = this.segments.length * SEG;

    // roadside dressing
    const bbTexts: Array<[string, string]> = [
      ["APEX RUSH", "#ffb347"], ["TURBO FUEL", "#3fe8d2"], ["SUNSET GP", "#ff5c38"],
      ["NITRO ZONE", "#3fe8d2"], ["FULL SEND", "#ffb347"],
    ];
    this.billboards = [];
    let bb = 0;
    for (let i = 90; i < this.segments.length - 20; i += 140) {
      const [text, accent] = bbTexts[bb++ % bbTexts.length];
      const sprite = makeBillboard(text, accent);
      const entry: RoadSprite = { sprite, offset: (bb % 2 ? 1 : -1) * (1.9 + rnd() * 0.4), worldW: 1500 };
      this.segments[i].sprites.push(entry);
      this.billboards.push({ entry, text, accent });
    }
    let i = 20;
    while (i < this.segments.length - 10) {
      const side = rnd() > 0.5 ? 1 : -1;
      const roll = rnd();
      if (roll < 0.62) {
        const p = this.palmImgs[Math.floor(rnd() * 3)];
        this.segments[i].sprites.push({ sprite: p, offset: side * (1.5 + rnd() * 2.4), worldW: 850 + rnd() * 550 });
      } else if (roll < 0.88) {
        this.segments[i].sprites.push({ sprite: this.cactusImg, offset: side * (1.35 + rnd() * 2.2), worldW: 380 + rnd() * 200 });
      } else {
        const p = this.palmImgs[Math.floor(rnd() * 3)];
        this.segments[i].sprites.push({ sprite: p, offset: side * (1.6 + rnd() * 2), worldW: 800 + rnd() * 400 });
        this.segments[i].sprites.push({ sprite: this.cactusImg, offset: -side * (1.4 + rnd() * 2), worldW: 360 + rnd() * 180 });
      }
      i += 6 + Math.floor(rnd() * 9);
    }
    for (const s of this.segments) {
      if (Math.abs(s.curve) >= 3 && s.index % 9 === 0) {
        s.sprites.push({ sprite: s.curve > 0 ? this.chevR : this.chevL, offset: -Math.sign(s.curve) * 1.32, worldW: 500 });
      }
    }
    this.segments[4].sprites.push({ sprite: this.gantry, offset: 0, worldW: 5600 });

    // traffic
    this.cars = [];
    const recent: Array<{ z: number; lane: number }> = [];
    let z = 60 * SEG;
    while (z < this.trackLen - 30 * SEG) {
      const laneIdx = Math.floor(rnd() * LANES);
      let lane = [-0.67, 0, 0.67][laneIdx];
      // never wall off all three lanes within a short window
      const near = recent.filter((r) => z - r.z < 9 * SEG);
      const lanesNear = new Set(near.map((r) => r.lane));
      if (lanesNear.size === 2 && !lanesNear.has(laneIdx)) {
        lane = [-0.67, 0, 0.67][near[0].lane];
      }
      const spriteIdx = Math.floor(rnd() * this.trafficImgs.length);
      const sp = this.trafficImgs[spriteIdx];
      const base = sp.kind === "truck" ? 0.2 + rnd() * 0.1 : sp.kind === "sport" ? 0.48 + rnd() * 0.14 : 0.28 + rnd() * 0.2;
      const car: Car = {
        z, offset: lane + (rnd() - 0.5) * 0.1,
        speed: MAX_SPEED * base, baseSpeed: MAX_SPEED * base,
        sprite: spriteIdx,
        hitDx: ((PLAYER_W + sp.worldW) / 2 / ROAD_W) * 0.88,
        segIdx: Math.floor(z / SEG) % this.segments.length,
        prevRel: 0,
      };
      this.cars.push(car);
      this.segments[car.segIdx].cars.push(car);
      recent.push({ z, lane: [-0.67, 0, 0.67].indexOf(lane) >= 0 ? [-0.67, 0, 0.67].indexOf(lane) : laneIdx });
      if (recent.length > 6) recent.shift();
      z += (14 + rnd() * 20) * SEG;
    }
    // initialize prevRel
    const pf = PLAYER_Z % this.trackLen;
    for (const c of this.cars) c.prevRel = (c.z - pf + this.trackLen) % this.trackLen;
  }

  /** Cars that lapped the track during the countdown can sit on the start line — relocate them ahead. */
  private clearLaunchZone() {
    const pf = (this.position + PLAYER_Z) % this.trackLen;
    const N = this.segments.length;
    for (const car of this.cars) {
      const rel = (car.z - pf + this.trackLen) % this.trackLen;
      if (rel > this.trackLen - 2500 || rel < 1200) {
        const old = this.segments[car.segIdx].cars;
        const oi = old.indexOf(car);
        if (oi >= 0) old.splice(oi, 1);
        car.z = (pf + 9000 + Math.random() * 12000) % this.trackLen;
        car.segIdx = Math.floor(car.z / SEG) % N;
        this.segments[car.segIdx].cars.push(car);
        car.prevRel = (car.z - pf + this.trackLen) % this.trackLen;
      }
    }
  }

  private findSeg(z: number): Segment {
    const n = this.segments.length;
    const i = Math.floor(z / SEG);
    return this.segments[((i % n) + n) % n];
  }

  /* ------------------------------------------------ input */
  private onKeyDown = (e: KeyboardEvent) => {
    if ((e.target as HTMLElement)?.tagName === "INPUT") return;
    const c = e.code;
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Space"].includes(c)) e.preventDefault();
    switch (c) {
      case "ArrowLeft": case "KeyA": this.input.left = true; break;
      case "ArrowRight": case "KeyD": this.input.right = true; break;
      case "ArrowDown": case "KeyS": this.input.brake = true; break;
      case "Space": case "ShiftLeft": case "ShiftRight": this.input.nitro = true; break;
    }
    if (e.repeat) return;
    switch (c) {
      case "KeyM": this.toggleMute(); break;
      case "KeyP": case "Escape":
        if (this.phase === "playing" || this.phase === "countdown" || this.phase === "paused") this.togglePause();
        break;
      case "Enter": case "Space":
        if (this.phase === "menu") this.startRun();
        else if (this.phase === "gameover") this.restart();
        else if (this.phase === "paused" && c === "Enter") this.resume();
        break;
      case "KeyR":
        if (this.phase !== "menu" && this.phase !== "crashing") this.restart();
        break;
    }
  };
  private onKeyUp = (e: KeyboardEvent) => {
    switch (e.code) {
      case "ArrowLeft": case "KeyA": this.input.left = false; break;
      case "ArrowRight": case "KeyD": this.input.right = false; break;
      case "ArrowDown": case "KeyS": this.input.brake = false; break;
      case "Space": case "ShiftLeft": case "ShiftRight": this.input.nitro = false; break;
    }
  };
  private onVis = () => {
    if (document.hidden && (this.phase === "playing" || this.phase === "countdown")) this.pause();
  };

  /* ------------------------------------------------ resize & quality */
  private resize = () => {
    const q = QUALITY[this.tier];
    this.dpr = Math.min(window.devicePixelRatio || 1, q.dpr);
    this.drawDist = q.draw;
    this.w = window.innerWidth;
    this.h = window.innerHeight;
    this.canvas.width = Math.round(this.w * this.dpr);
    this.canvas.height = Math.round(this.h * this.dpr);
    this.canvas.style.width = `${this.w}px`;
    this.canvas.style.height = `${this.h}px`;
    this.fogStops = [];
    for (let n = 0; n < this.drawDist; n++) {
      const f = 1 - Math.exp(-((n / this.drawDist) ** 2) * 4.2);
      this.fogStops.push(`rgba(${COLORS.fog},${f.toFixed(3)})`);
    }
    this.buildSky();
  };

  private buildSky() {
    const w = Math.ceil(this.w * 1.3), h = this.h;
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    const ctx = c.getContext("2d")!;
    const horizon = h * 0.44;
    const g = ctx.createLinearGradient(0, 0, 0, horizon * 1.05);
    g.addColorStop(0, "#0d1b33");
    g.addColorStop(0.4, "#1c2748");
    g.addColorStop(0.66, "#4c3560");
    g.addColorStop(0.85, "#a34a4e");
    g.addColorStop(1, "#ff9a55");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, horizon + 2);
    // stars
    const rnd = mulberry32(42);
    ctx.fillStyle = "rgba(244,231,205,0.8)";
    for (let i = 0; i < 110; i++) {
      const y = rnd() * h * 0.26;
      ctx.globalAlpha = 0.15 + rnd() * 0.6;
      ctx.fillRect(rnd() * w, y, rnd() > 0.85 ? 2 : 1.3, rnd() > 0.85 ? 2 : 1.3);
    }
    ctx.globalAlpha = 1;
    // sun
    const sun = makeSun(h * 0.17);
    ctx.drawImage(sun, w * 0.52 - sun.width / 2, horizon - h * 0.175 - sun.height / 2 + h * 0.02);
    // warm cloud streaks
    for (let i = 0; i < 6; i++) {
      const y = horizon * (0.55 + rnd() * 0.4);
      const cw = w * (0.1 + rnd() * 0.22);
      const x = rnd() * w;
      const cg = ctx.createLinearGradient(x, 0, x + cw, 0);
      cg.addColorStop(0, "rgba(255,150,90,0)");
      cg.addColorStop(0.5, `rgba(255,${150 + Math.floor(rnd() * 60)},110,${0.14 + rnd() * 0.12})`);
      cg.addColorStop(1, "rgba(255,150,90,0)");
      ctx.fillStyle = cg;
      ctx.fillRect(x, y, cw, 3 + rnd() * 5);
    }
    // ground base below horizon (visible through hill gaps)
    ctx.fillStyle = COLORS.grassB;
    ctx.fillRect(0, horizon - h * 0.05, w, h);
    const haze = ctx.createLinearGradient(0, horizon - h * 0.05, 0, horizon + h * 0.04);
    haze.addColorStop(0, "rgba(255,140,80,0.34)");
    haze.addColorStop(1, "rgba(255,140,80,0)");
    ctx.fillStyle = haze;
    ctx.fillRect(0, horizon - h * 0.05, w, h * 0.09);
    this.sky = c;
  }

  /* ------------------------------------------------ main loop */
  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const rawDt = (now - this.last) / 1000;
    this.last = now;
    // first RAF timestamp can predate construction → clamp negative deltas
    const dt = clamp(rawDt, 0, 1 / 30);

    // adaptive quality watchdog
    this.warmup += rawDt;
    if (this.warmup > 3 && (this.phase === "playing" || this.phase === "menu")) {
      this.frameAcc += rawDt; this.frameCnt++;
      if (this.frameCnt >= 90) {
        if (this.frameAcc / this.frameCnt > 0.021 && this.tier < QUALITY.length - 1) {
          this.tier++;
          this.resize();
        }
        this.frameAcc = 0; this.frameCnt = 0;
      }
    }

    if (this.phase === "paused") return; // frozen frame stays on screen

    this.time += dt;
    this.update(dt);
    this.render();
  };

  /* ------------------------------------------------ update */
  private update(dt: number) {
    const sim = dt * this.timeScale;

    if (this.phase === "menu") {
      // attract-mode autopilot
      this.speed = lerp(this.speed, MAX_SPEED * 0.52, dt * 0.8);
      const seg = this.findSeg(this.position + PLAYER_Z);
      const target = Math.sin(this.time * 0.22) * 0.5 - seg.curve * 0.09;
      this.playerX = lerp(this.playerX, target, dt * 1.4);
      this.steer = lerp(this.steer, clamp(target - this.playerX, -1, 1), dt * 4);
      this.position = (this.position + this.speed * sim) % this.trackLen;
      this.bgOffset -= seg.curve * (this.speed / MAX_SPEED) * dt * 26;
      this.updateTraffic(sim);
      this.updateFx(dt, sim);
      this.audio.updateEngine(this.speed / MAX_SPEED, false, false, false);
      return;
    }

    if (this.phase === "countdown") {
      this.cdTimer -= dt;
      this.steer = lerp(this.steer, (this.input.right ? 1 : 0) - (this.input.left ? 1 : 0), Math.min(1, dt * 10));
      if (this.cdTimer <= 0) {
        this.cdValue--;
        if (this.cdValue > 0) {
          this.cdTimer = this.cdStep;
          this.cb.onCountdown(this.cdValue);
          this.audio.countBeep();
        } else {
          this.cb.onCountdown(0);
          this.audio.goBeep();
          this.goHide = 0.7;
          this.protection = 1.0;
          this.clearLaunchZone();
          this.setPhase("playing");
        }
      }
      this.updateTraffic(sim);
      this.updateFx(dt, sim);
      this.audio.updateEngine(0.12 + Math.abs(Math.sin(this.time * 9)) * 0.1, false, false, true);
      this.writeHud();
      return;
    }

    if (this.phase === "crashing") {
      this.crashT -= dt;
      this.speed = Math.max(0, this.speed - MAX_SPEED * 1.6 * sim);
      this.position = (this.position + this.speed * sim) % this.trackLen;
      this.spin += this.spinDir * sim * 11;
      this.updateTraffic(sim);
      this.updateFx(dt, sim);
      this.audio.updateEngine(this.speed / MAX_SPEED, false, false, true);
      if (this.crashT <= 0) {
        this.timeScale = 1;
        this.audio.updateEngine(0, false, false, false);
        this.audio.gameOver();
        const stats: RunStats = {
          score: Math.floor(this.score),
          dist: Math.floor(this.totalM),
          topSpeed: Math.round(this.topSpeed),
          nearMisses: this.nearMisses,
          best: this.best,
          isRecord: Math.floor(this.score) > this.best,
        };
        this.setPhase("gameover", stats);
      }
      return;
    }

    if (this.phase === "gameover") {
      this.updateFx(dt, sim);
      this.audio.updateEngine(0, false, false, false);
      return;
    }

    /* -------- playing -------- */
    if (this.goHide > 0) {
      this.goHide -= dt;
      if (this.goHide <= 0) this.cb.onCountdown(-1);
    }
    if (this.protection > 0) this.protection -= dt;

    // nitro
    const wasNitro = this.nitroActive;
    this.nitroActive = this.input.nitro && (this.nitroActive ? this.nitroMeter > 0 : this.nitroMeter >= 15);
    if (this.nitroActive && !wasNitro) {
      this.audio.nitroIgnite();
      this.shake = Math.max(this.shake, 5);
    }
    if (this.nitroActive) this.nitroMeter = Math.max(0, this.nitroMeter - 30 * sim);
    else this.nitroMeter = Math.min(100, this.nitroMeter + 2.2 * sim);
    this.camD = lerp(this.camD, this.nitroActive ? CAM_D * 0.92 : CAM_D, Math.min(1, dt * 4));

    // speed
    const curMax = MAX_SPEED * (this.nitroActive ? NITRO_MULT : 1);
    if (this.input.brake) this.speed -= (MAX_SPEED / 1.3) * sim;
    else if (this.speed < curMax) this.speed += (MAX_SPEED / 4.2) * (this.nitroActive ? 2.3 : 1) * sim;
    else this.speed -= (MAX_SPEED / 2.6) * sim;
    const offroad = Math.abs(this.playerX) > 1.02;
    if (offroad && this.speed > MAX_SPEED * 0.35) this.speed -= (MAX_SPEED / 1.5) * sim;
    this.speed = clamp(this.speed, 0, MAX_SPEED * NITRO_MULT);

    // steering
    const steerTarget = (this.input.right ? 1 : 0) - (this.input.left ? 1 : 0);
    this.steer = lerp(this.steer, steerTarget, Math.min(1, dt * 14));
    const seg = this.findSeg(this.position + PLAYER_Z);
    const pct = this.speed / MAX_SPEED;
    this.playerX += this.steer * sim * 2.35 * (0.25 + 0.75 * Math.min(1, pct));
    this.playerX -= sim * pct * pct * seg.curve * CENTRIFUGAL;
    this.playerX = clamp(this.playerX, -2.2, 2.2);

    // advance
    this.position = (this.position + this.speed * sim) % this.trackLen;
    this.totalM += this.speed * sim * METERS;
    this.bgOffset -= seg.curve * pct * sim * 26;
    this.topSpeed = Math.max(this.topSpeed, this.speed * KMH);

    // scoring
    this.score += ((this.speed * sim) / 150) * 3 * (this.nitroActive ? 2 : 1);
    if (!this.recordFired && this.best > 0 && this.score > this.best) {
      this.recordFired = true;
      this.pushPopup("NEW RECORD!", this.w / 2, this.h * 0.34, "#ffd23e", 34);
      this.audio.record();
    }
    if (this.totalM >= this.nextKm) {
      this.score += 500;
      this.pushPopup(`${this.nextKm / 1000} km  +500`, this.w / 2, this.h * 0.3, "#f4e7cd", 26);
      this.audio.milestone();
      this.nextKm += 1000;
    }
    if (this.comboT > 0) {
      this.comboT -= sim;
      if (this.comboT <= 0) this.combo = 0;
    }

    this.updateTraffic(sim);
    this.checkTraffic(seg, sim);

    // fx: offroad dust & rumble
    if (offroad && this.speed > MAX_SPEED * 0.1) {
      this.shake = Math.max(this.shake, 2.6);
      if (Math.random() > 0.4) {
        const cw = this.playerScreenW();
        this.spawnParticle(
          this.w / 2 + (Math.random() > 0.5 ? 1 : -1) * cw * 0.4, this.playerBaseY() - 6,
          (Math.random() - 0.5) * 90, -60 - Math.random() * 120, 260,
          0.5 + Math.random() * 0.3, 5 + Math.random() * 7, "rgba(140,110,80,0.5)", false, false,
        );
      }
    }
    // nitro flames
    if (this.nitroActive) {
      this.shake = Math.max(this.shake, 1.1);
      const cw = this.playerScreenW();
      for (let k = 0; k < 3; k++) {
        const side = k % 2 ? 1 : -1;
        this.spawnParticle(
          this.w / 2 + side * cw * 0.185 + (Math.random() - 0.5) * 5, this.playerBaseY() - 8,
          (Math.random() - 0.5) * 40, 130 + Math.random() * 200, 0,
          0.16 + Math.random() * 0.12, 4 + Math.random() * 6,
          Math.random() > 0.45 ? "#3fe8d2" : Math.random() > 0.5 ? "#c9fff6" : "#ffb347",
          true, true,
        );
      }
    }

    this.updateFx(dt, sim);
    this.audio.updateEngine(Math.min(1, pct), this.nitroActive, offroad, true);
    this.writeHud();
  }

  private playerScreenW() {
    return PLAYER_W * (this.camD / PLAYER_Z) * (this.w / 2);
  }

  /* ------------------------------------------------ traffic */
  private updateTraffic(dt: number) {
    const N = this.segments.length;
    for (const car of this.cars) {
      // gentle follow AI: don't rear-end the car ahead
      let target = car.baseSpeed;
      const aheadIdx = car.segIdx;
      for (let k = 1; k <= 3; k++) {
        const s = this.segments[(aheadIdx + k) % N];
        for (const other of s.cars) {
          if (other !== car && Math.abs(other.offset - car.offset) < 0.34 && other.speed < target) {
            target = other.speed * 0.97;
          }
        }
      }
      car.speed = target < car.speed ? target : Math.min(car.baseSpeed, car.speed + MAX_SPEED * 0.04 * dt);
      car.z = (car.z + car.speed * dt) % this.trackLen;
      const idx = Math.floor(car.z / SEG) % N;
      if (idx !== car.segIdx) {
        const old = this.segments[car.segIdx].cars;
        const oi = old.indexOf(car);
        if (oi >= 0) old.splice(oi, 1);
        this.segments[idx].cars.push(car);
        car.segIdx = idx;
      }
    }
  }

  private checkTraffic(playerSeg: Segment, sim: number) {
    const pf = (this.position + PLAYER_Z) % this.trackLen;
    const half = this.trackLen / 2;
    for (const car of this.cars) {
      const rel = (car.z - pf + this.trackLen) % this.trackLen;
      const dx = Math.abs(this.playerX - car.offset);
      // genuine overtake: it was just ahead of our nose and we're faster
      const crossed = car.prevRel < 2500 && rel >= half && this.speed > car.speed;
      // slower traffic can never rear-end us — we only crash when we're the faster car
      const overlapping = rel > this.trackLen - (170 + 160) && this.speed > car.speed;
      if ((crossed || overlapping) && dx < car.hitDx) {
        if (this.protection <= 0) {
          car.prevRel = rel;
          this.doCrash();
          return;
        }
      }
      if (crossed && this.phase === "playing") {
        if (dx < NEAR_MISS_DX && this.speed > MAX_SPEED * 0.35) {
          this.combo = Math.min(9, this.combo + 1);
          this.comboT = COMBO_WINDOW;
          this.nearMisses++;
          const pts = 150 * this.combo * (this.nitroActive ? 2 : 1);
          this.score += pts;
          this.nitroMeter = Math.min(100, this.nitroMeter + 16);
          this.audio.nearMiss(this.combo);
          this.shake = Math.max(this.shake, 2);
          const sx = this.w / 2 + (car.offset > this.playerX ? 1 : -1) * this.w * 0.17;
          this.pushPopup(`NEAR MISS +${pts}`, sx, this.h * 0.58, "#3fe8d2", 22);
          if (this.combo > 1) this.pushPopup(`COMBO ×${this.combo}`, sx, this.h * 0.58 - 30, "#ffd23e", 18);
          for (let k = 0; k < 8; k++) {
            this.spawnParticle(
              sx, this.h * 0.66, (Math.random() - 0.5) * 320, -80 - Math.random() * 200, 300,
              0.3 + Math.random() * 0.2, 2 + Math.random() * 3, "#c9fff6", true, true,
            );
          }
          const cw = this.hud.comboWrap;
          if (cw) {
            cw.classList.remove("anim-chip");
            void cw.offsetWidth;
            cw.classList.add("anim-chip");
          }
        } else {
          this.score += 30;
          this.nitroMeter = Math.min(100, this.nitroMeter + 3);
        }
      }
      car.prevRel = rel;
    }
    void playerSeg; void sim;
  }

  private doCrash() {
    this.audio.crash();
    this.shake = 26;
    this.flash = 1;
    this.timeScale = 0.22;
    this.crashT = 1.3;
    this.spinDir = this.steer >= 0 ? 1 : -1;
    this.nitroActive = false;
    this.combo = 0;
    const cx = this.w / 2, cy = this.playerBaseY() - this.playerScreenW() * 0.3;
    for (let k = 0; k < 60; k++) {
      const a = Math.random() * Math.PI * 2;
      const v = 120 + Math.random() * 560;
      this.spawnParticle(
        cx + (Math.random() - 0.5) * 60, cy - 30,
        Math.cos(a) * v, Math.sin(a) * v - 160, 620,
        0.5 + Math.random() * 0.7, 2 + Math.random() * 4,
        Math.random() > 0.4 ? "#ffb347" : Math.random() > 0.5 ? "#ff5c38" : "#fff0c2",
        true, true,
      );
    }
    for (let k = 0; k < 22; k++) {
      this.spawnParticle(
        cx + (Math.random() - 0.5) * 90, cy - 20 - Math.random() * 40,
        (Math.random() - 0.5) * 130, -40 - Math.random() * 130, -60,
        0.9 + Math.random() * 1.1, 12 + Math.random() * 18, "rgba(60,60,70,0.55)", false, false,
      );
    }
    this.setPhase("crashing");
  }

  /* ------------------------------------------------ fx */
  private spawnParticle(x: number, y: number, vx: number, vy: number, g: number, life: number, size: number, color: string, add: boolean, shrink: boolean) {
    if (this.particles.length > 320) this.particles.shift();
    this.particles.push({ x, y, vx, vy, g, life, max: life, size, color, add, shrink });
  }
  private pushPopup(text: string, x: number, y: number, color: string, size: number) {
    if (this.popups.length > 20) this.popups.shift();
    this.popups.push({ x, y, text, color, size, life: 1.1, max: 1.1 });
  }
  private updateFx(dt: number, sim: number) {
    this.shake = Math.max(0, this.shake - dt * 26);
    this.flash = Math.max(0, this.flash - dt * 1.6);
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= sim;
      if (p.life <= 0) { this.particles.splice(i, 1); continue; }
      p.vy += p.g * sim;
      p.x += p.vx * sim;
      p.y += p.vy * sim;
    }
    for (let i = this.popups.length - 1; i >= 0; i--) {
      const p = this.popups[i];
      p.life -= dt;
      p.y -= 42 * dt;
      if (p.life <= 0) this.popups.splice(i, 1);
    }
  }

  /* ------------------------------------------------ HUD */
  private setText(el: HTMLElement | null | undefined, text: string) {
    if (!el) return;
    if (this.hudCache.get(el) !== text) {
      this.hudCache.set(el, text);
      el.textContent = text;
    }
  }
  private lastScoreShown = -1;
  private lastBestShown = -1;
  private writeHud() {
    const h = this.hud;
    const sInt = Math.floor(this.score);
    if (sInt !== this.lastScoreShown) {
      this.lastScoreShown = sInt;
      this.setText(h.score, sInt.toLocaleString("en-US"));
    }
    const bInt = Math.max(this.best, sInt);
    if (bInt !== this.lastBestShown) {
      this.lastBestShown = bInt;
      this.setText(h.best, bInt.toLocaleString("en-US"));
    }
    this.setText(h.speed, String(Math.round(this.speed * KMH)));
    this.setText(h.dist, `${(this.totalM / 1000).toFixed(2)} km`);
    if (h.nitroFill) h.nitroFill.style.transform = `scaleX(${(this.nitroMeter / 100).toFixed(3)})`;
    if (h.nitroWrap) {
      const state = this.nitroActive ? "active" : this.nitroMeter >= 15 ? "ready" : "low";
      if (h.nitroWrap.dataset.state !== state) {
        h.nitroWrap.dataset.state = state;
        h.nitroWrap.classList.toggle("anim-nitro-ready", state === "ready");
      }
    }
    this.setText(h.nitroLabel, this.nitroActive ? "BOOSTING ×2" : this.nitroMeter >= 15 ? "NITRO READY" : "NITRO");
    if (h.comboWrap) h.comboWrap.style.opacity = this.combo > 1 ? "1" : "0";
    this.setText(h.combo, `×${Math.max(2, this.combo)}`);
    if (h.comboBar) h.comboBar.style.transform = `scaleX(${(this.comboT / COMBO_WINDOW).toFixed(3)})`;
    if (h.multWrap) h.multWrap.style.opacity = this.nitroActive ? "1" : "0";
  }

  /* ------------------------------------------------ render */
  private project(p: Pt, camX: number, camY: number, camZ: number) {
    p.camera.x = -camX;
    p.camera.y = p.world.y - camY;
    p.camera.z = p.world.z - camZ;
    const s = this.camD / p.camera.z;
    p.screen.scale = s;
    p.screen.x = this.w / 2 + (s * p.camera.x * this.w) / 2;
    p.screen.y = this.h / 2 - (s * p.camera.y * this.h) / 2;
    p.screen.w = (s * ROAD_W * this.w) / 2;
  }

  private quad(color: string, x1: number, y1: number, w1: number, x2: number, y2: number, w2: number) {
    const ctx = this.ctx;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x1 - w1, y1);
    ctx.lineTo(x1 + w1, y1);
    ctx.lineTo(x2 + w2, y2);
    ctx.lineTo(x2 - w2, y2);
    ctx.closePath();
    ctx.fill();
  }

  private render() {
    const ctx = this.ctx;
    const { w, h } = this;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    if (this.shake > 0.05) {
      ctx.translate((Math.random() - 0.5) * 2 * this.shake, (Math.random() - 0.5) * 2 * this.shake);
    }

    const baseSeg = this.findSeg(this.position);
    const basePct = (this.position % SEG) / SEG;
    const playerSeg = this.findSeg(this.position + PLAYER_Z);
    const playerPct = ((this.position + PLAYER_Z) % SEG) / SEG;
    const playerY = lerp(playerSeg.p1.world.y, playerSeg.p2.world.y, playerPct);
    const speedPct = this.speed / MAX_SPEED;
    const horizon = h * 0.44 + clamp(-playerY * 0.006, -h * 0.045, h * 0.045);

    // sky
    if (this.sky) {
      const shift = clamp(this.bgOffset * 0.06, -w * 0.14, w * 0.14);
      ctx.drawImage(this.sky, -w * 0.15 + shift, 0, w * 1.3, h);
    }
    // mountains (two parallax layers)
    const drawStrip = (img: HTMLCanvasElement, hgt: number, par: number) => {
      const tileW = w * 1.25;
      let off = (this.bgOffset * par) % tileW;
      if (off > 0) off -= tileW;
      for (let x = off; x < w; x += tileW) {
        ctx.drawImage(img, x, horizon - hgt + 2, tileW, hgt);
      }
    };
    drawStrip(this.mtnFar, h * 0.15, 0.35);
    drawStrip(this.mtnNear, h * 0.1, 0.7);

    // road segments
    const N = this.segments.length;
    let maxy = h;
    let x = 0;
    let dx = -(baseSeg.curve * basePct);
    const camX = this.playerX * ROAD_W;
    for (let n = 0; n < this.drawDist; n++) {
      const seg = this.segments[(baseSeg.index + n) % N];
      const looped = seg.index < baseSeg.index;
      const camZ = this.position - (looped ? this.trackLen : 0);
      seg.clip = maxy;
      this.project(seg.p1, camX - x, playerY + CAM_H, camZ);
      this.project(seg.p2, camX - x - dx, playerY + CAM_H, camZ);
      x += dx;
      dx += seg.curve;
      if (seg.p1.camera.z <= this.camD || seg.p2.screen.y >= seg.p1.screen.y || seg.p2.screen.y >= maxy) continue;

      const p1 = seg.p1.screen, p2 = seg.p2.screen;
      const row = Math.floor(seg.index / 3) % 2;
      // grass
      ctx.fillStyle = row ? COLORS.grassA : COLORS.grassB;
      ctx.fillRect(0, p2.y, w, p1.y - p2.y + 1);
      // rumbles (skip once sub-pixel near the horizon)
      const r1 = p1.w / 6, r2 = p2.w / 6;
      if (r1 > 0.6) {
        const rumble = row ? COLORS.rumbleA : COLORS.rumbleB;
        this.quad(rumble, p1.x - p1.w - r1 / 2, p1.y, r1 / 2, p2.x - p2.w - r2 / 2, p2.y, r2 / 2);
        this.quad(rumble, p1.x + p1.w + r1 / 2, p1.y, r1 / 2, p2.x + p2.w + r2 / 2, p2.y, r2 / 2);
      }
      // road
      const roadColor = seg.index < 2 ? COLORS.start : row ? COLORS.roadA : COLORS.roadB;
      this.quad(roadColor, p1.x, p1.y, p1.w, p2.x, p2.y, p2.w);
      // lane dashes
      if (row === 0 && seg.index >= 2 && p1.w > 8) {
        const lw1 = p1.w / 28, lw2 = p2.w / 28;
        for (let lane = 1; lane < LANES; lane++) {
          const lx1 = p1.x - p1.w + ((p1.w * 2) / LANES) * lane;
          const lx2 = p2.x - p2.w + ((p2.w * 2) / LANES) * lane;
          this.quad(COLORS.lane, lx1, p1.y, lw1, lx2, p2.y, lw2);
        }
      }
      // fog
      const fog = this.fogStops[n];
      if (n > this.drawDist * 0.35) {
        ctx.fillStyle = fog;
        ctx.fillRect(0, p2.y, w, p1.y - p2.y + 1);
      }
      maxy = p2.y;
    }

    // sprites & traffic, back to front
    for (let n = this.drawDist - 1; n > 0; n--) {
      const seg = this.segments[(baseSeg.index + n) % N];
      if (seg.p1.camera.z <= this.camD) continue;
      for (const rs of seg.sprites) {
        const scale = seg.p1.screen.scale;
        const destW = rs.worldW * scale * (w / 2);
        if (destW < 2 || destW > w * 4) continue;
        const sx = seg.p1.screen.x + scale * rs.offset * ROAD_W * (w / 2);
        if (sx + destW / 2 < -20 || sx - destW / 2 > w + 20) continue;
        const destH = destW * rs.sprite.aspect;
        const sy = seg.p1.screen.y;
        if (sy - destH > h) continue;
        const clipH = Math.max(0, sy - seg.clip);
        if (clipH >= destH) continue;
        const img = rs.sprite.img;
        ctx.drawImage(
          img, 0, 0, img.width, img.height * (1 - clipH / destH),
          sx - destW / 2, sy - destH, destW, destH - clipH,
        );
      }
      for (const car of seg.cars) {
        const cpct = (car.z % SEG) / SEG;
        const scale = lerp(seg.p1.screen.scale, seg.p2.screen.scale, cpct);
        if (scale <= 0) continue;
        const sp = this.trafficImgs[car.sprite];
        const destW = sp.worldW * scale * (w / 2);
        if (destW < 2 || destW > w * 4) continue;
        const sx = lerp(seg.p1.screen.x, seg.p2.screen.x, cpct) + scale * car.offset * ROAD_W * (w / 2);
        if (sx + destW / 2 < -20 || sx - destW / 2 > w + 20) continue;
        const destH = destW * sp.aspect;
        const sy = lerp(seg.p1.screen.y, seg.p2.screen.y, cpct);
        if (sy - destH > h) continue;
        const clipH = Math.max(0, sy - seg.clip);
        if (clipH >= destH) continue;
        ctx.drawImage(
          sp.img, 0, 0, sp.img.width, sp.img.height * (1 - clipH / destH),
          sx - destW / 2, sy - destH, destW, destH - clipH,
        );
      }
    }

    this.renderPlayer(speedPct);
    this.renderParticles();
    this.renderSpeedLines(speedPct);
    this.renderPopups();

    // nitro tint & crash flash
    if (this.nitroActive) {
      ctx.fillStyle = `rgba(63,232,210,${0.06 + Math.random() * 0.03})`;
      ctx.fillRect(0, 0, w, h);
    }
    if (this.flash > 0) {
      ctx.fillStyle = `rgba(255,222,180,${(this.flash * 0.85).toFixed(3)})`;
      ctx.fillRect(0, 0, w, h);
    }
  }

  private renderPlayer(speedPct: number) {
    const ctx = this.ctx;
    const destW = this.playerScreenW();
    const img = this.input.brake && this.phase === "playing" ? this.playerBrake : this.playerImg;
    const destH = destW * img.aspect;
    const bounce = Math.sin(this.time * 26) * speedPct * 2.2;
    const cx = this.w / 2 + this.steer * 7;
    const cy = this.playerBaseY() - destH / 2 + bounce;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(this.steer * 0.085 + this.spin);
    if (this.protection > 0 && this.phase === "playing") {
      ctx.globalAlpha = 0.55 + 0.45 * Math.abs(Math.sin(this.time * 14));
    }
    ctx.drawImage(img.img, -destW / 2, -destH / 2, destW, destH);
    ctx.restore();
  }

  private renderParticles() {
    const ctx = this.ctx;
    for (const pass of [false, true]) {
      if (pass) ctx.globalCompositeOperation = "lighter";
      for (const p of this.particles) {
        if (p.add !== pass) continue;
        const t = p.life / p.max;
        ctx.globalAlpha = clamp(t, 0, 1);
        ctx.fillStyle = p.color;
        const s = p.shrink ? p.size * t : p.size * (1.6 - t * 0.6);
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(0.5, s), 0, Math.PI * 2);
        ctx.fill();
      }
      if (pass) ctx.globalCompositeOperation = "source-over";
    }
    ctx.globalAlpha = 1;
  }

  private renderSpeedLines(speedPct: number) {
    let f = clamp((speedPct - 0.72) / 0.4, 0, 1);
    if (this.nitroActive) f = Math.max(f, 0.75);
    if (f <= 0.02 || this.phase === "crashing") return;
    const ctx = this.ctx;
    const cx = this.w / 2, cy = this.h * 0.42;
    const R = Math.hypot(this.w, this.h) * 0.55;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.lineWidth = 2;
    for (const r of this.rays) {
      const d = (r.off + this.time * (0.9 + speedPct)) % 1;
      const r0 = (0.4 + d * 0.75) * R;
      const alpha = f * (1 - d) * 0.4;
      if (alpha < 0.02) continue;
      ctx.strokeStyle = this.nitroActive ? `rgba(160,255,240,${alpha})` : `rgba(244,231,205,${alpha * 0.8})`;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(r.a) * r0, cy + Math.sin(r.a) * r0 * 0.8);
      ctx.lineTo(cx + Math.cos(r.a) * (r0 + r.len * R), cy + Math.sin(r.a) * (r0 + r.len * R) * 0.8);
      ctx.stroke();
    }
    ctx.restore();
  }

  private renderPopups() {
    const ctx = this.ctx;
    ctx.textAlign = "center";
    for (const p of this.popups) {
      const t = p.life / p.max;
      ctx.globalAlpha = clamp(t * 1.6, 0, 1);
      ctx.font = `700 ${p.size}px 'Chakra Petch', monospace`;
      ctx.lineWidth = 4;
      ctx.strokeStyle = "rgba(6,10,20,0.85)";
      ctx.strokeText(p.text, p.x, p.y);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text, p.x, p.y);
    }
    ctx.globalAlpha = 1;
  }
}