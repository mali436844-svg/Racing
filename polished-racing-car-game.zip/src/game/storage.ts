export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  dist: number; // meters
  topSpeed: number; // km/h
  date: number;
}

const SCORES_KEY = "apex-rush-scores-v1";
const NAME_KEY = "apex-rush-name-v1";
const MUTE_KEY = "apex-rush-muted-v1";
export const TABLE_SIZE = 5;

function safeGet(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}
function safeSet(key: string, value: string) {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* private mode – ignore */
  }
}

export function loadScores(): ScoreEntry[] {
  const raw = safeGet(SCORES_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((e) => e && typeof e.score === "number")
      .sort((a, b) => b.score - a.score)
      .slice(0, TABLE_SIZE);
  } catch {
    return [];
  }
}

export function bestScore(scores: ScoreEntry[]): number {
  return scores.length ? scores[0].score : 0;
}

export function qualifies(score: number, scores: ScoreEntry[]): boolean {
  if (score <= 0) return false;
  return scores.length < TABLE_SIZE || score > scores[scores.length - 1].score;
}

export function saveScores(scores: ScoreEntry[]) {
  safeSet(SCORES_KEY, JSON.stringify(scores.slice(0, TABLE_SIZE)));
}

/** Inserts a run into the table; returns the new table and the entry id (null if it didn't chart). */
export function recordRun(entry: Omit<ScoreEntry, "id" | "date">): { scores: ScoreEntry[]; id: string | null } {
  const scores = loadScores();
  if (!qualifies(entry.score, scores)) return { scores, id: null };
  const id = `${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
  const full: ScoreEntry = { ...entry, id, date: Date.now() };
  const next = [...scores, full].sort((a, b) => b.score - a.score).slice(0, TABLE_SIZE);
  saveScores(next);
  return { scores: next, id };
}

export function renameEntry(id: string, name: string): ScoreEntry[] {
  const scores = loadScores().map((e) => (e.id === id ? { ...e, name } : e));
  saveScores(scores);
  return scores;
}

export function loadLastName(): string {
  return safeGet(NAME_KEY) || "AAA";
}
export function saveLastName(name: string) {
  safeSet(NAME_KEY, name);
}

export function loadMuted(): boolean {
  return safeGet(MUTE_KEY) === "1";
}
export function saveMuted(muted: boolean) {
  safeSet(MUTE_KEY, muted ? "1" : "0");
}