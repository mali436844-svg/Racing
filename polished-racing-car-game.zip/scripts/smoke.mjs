import { chromium } from "playwright";
import http from "http";
import { readFileSync, mkdirSync } from "fs";

mkdirSync("tmp", { recursive: true });
const html = readFileSync("dist/index.html");
const server = http.createServer((_, res) => {
  res.setHeader("Content-Type", "text/html");
  res.end(html);
});
await new Promise((r) => server.listen(4517, r));

const URL = process.env.TEST_URL || "http://localhost:4517";
const errors = [];
const browser = await chromium.launch({ args: ["--no-sandbox", "--disable-dev-shm-usage"] });

async function newPage(viewport, hasTouch = false) {
  const ctx = await browser.newContext({ viewport, hasTouch, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => errors.push("PAGEERROR: " + (e.stack || e.message).split("\n").slice(0, 5).join(" | ")));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push("CONSOLE: " + m.text());
  });
  return { ctx, page };
}

const { ctx, page } = await newPage({ width: 1280, height: 800 });
await page.goto(URL);
await page.waitForTimeout(1500);
await page.keyboard.press("Enter");
await page.waitForTimeout(4000);
await page.screenshot({ path: "tmp/3-driving.png" });

// ---- steering controller: hold x≈0.33 (near-miss line), then center to force a crash
let held = null;
let maxNear = 0;
let maxCombo = 0;
let wrecked = false;
const t0 = Date.now();
while (Date.now() - t0 < 60000) {
  const st = await page.evaluate(() => {
    const e = window.__APEX__;
    return { phase: e.phase, x: e.playerX, near: e.nearMisses, combo: e.combo, score: e.score, meter: e.nitroMeter };
  });
  maxNear = Math.max(maxNear, st.near);
  maxCombo = Math.max(maxCombo, st.combo);
  if (st.phase === "gameover") { wrecked = true; break; }
  const target = Date.now() - t0 < 30000 ? 0.33 : 0;
  const want = st.x < target - 0.05 ? "ArrowRight" : st.x > target + 0.05 ? "ArrowLeft" : null;
  if (want !== held) {
    if (held) await page.keyboard.up(held);
    if (want) await page.keyboard.down(want);
    held = want;
  }
  if (st.near >= 3 && !global.shotCombo) {
    global.shotCombo = true;
    await page.screenshot({ path: "tmp/4-combo.png" });
  }
  await page.waitForTimeout(70);
}
if (held) await page.keyboard.up(held);
console.log("wrecked:", wrecked, "| nearMisses:", maxNear, "| maxCombo:", maxCombo);
await page.waitForTimeout(700);
await page.screenshot({ path: "tmp/6-gameover.png" });

if (wrecked) {
  const input = page.locator("input");
  if (await input.count()) { await input.fill("XYZ"); await input.press("Enter"); }
  const table = await page.evaluate(() => localStorage.getItem("apex-rush-scores-v1"));
  console.log("saved table:", table);
  await page.keyboard.press("KeyR");
  await page.waitForTimeout(2600);
  const phase2 = await page.evaluate(() => window.__APEX__.phase);
  console.log("after R phase:", phase2);
  await page.screenshot({ path: "tmp/7-restarted.png" });
}
await ctx.close();

// ---- mobile: verify touch buttons drive the engine
const m = await newPage({ width: 390, height: 844 }, true);
await m.page.goto(URL);
await m.page.waitForTimeout(1200);
await m.page.screenshot({ path: "tmp/8-mobile-menu.png" });
await m.page.tap("text=START ENGINE");
await m.page.waitForTimeout(3600);
await m.page.evaluate(() => { window.__APEX__.protection = 999; }); // test invulnerability
const left = m.page.locator('button[aria-label="Steer left"]');
await left.dispatchEvent("pointerdown", { pointerId: 7 });
await m.page.waitForTimeout(350);
const stM = await m.page.evaluate(() => ({ left: window.__APEX__.input.left, x: window.__APEX__.playerX }));
await left.dispatchEvent("pointerup", { pointerId: 7 });
const nitro = m.page.locator('button[aria-label="Nitro boost"]');
await nitro.dispatchEvent("pointerdown", { pointerId: 8 });
await m.page.waitForTimeout(400);
const stN = await m.page.evaluate(() => ({ nitro: window.__APEX__.input.nitro, active: window.__APEX__.nitroActive }));
await m.page.screenshot({ path: "tmp/9-mobile-play.png" });
await nitro.dispatchEvent("pointerup", { pointerId: 8 });
console.log("touch steer:", JSON.stringify(stM), "| touch nitro:", JSON.stringify(stN));
await m.ctx.close();

await browser.close();
server.close();
console.log("errors:", errors.length ? errors : "none");