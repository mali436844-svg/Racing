# 🏎️ APEX RUSH — Sunset Circuit Racer

A pseudo-3D arcade racing game. Weave through traffic, chain near-misses to charge nitro, and chase the sunset. Built with React + Vite + Tailwind, rendered on canvas at 60fps, with a fully synthesized WebAudio soundscape (no asset files — the whole game ships as one HTML file).

## Run locally

```bash
npm install
npm run dev        # dev server
npm run build      # production build → dist/index.html (self-contained)
```

## Deploy to Netlify

The repo already includes `netlify.toml`, so Netlify picks up the right settings automatically:

| Setting            | Value           |
| ------------------ | --------------- |
| Build command      | `npm run build` |
| Publish directory  | `dist`          |
| Node version       | `22`            |

### Option A — Drag & drop (fastest, ~1 minute)

1. Run `npm run build` locally.
2. Go to **https://app.netlify.com/drop** (log in / sign up free).
3. Drag the **`dist` folder** onto the page.
4. Done — you get a live `https://<name>.netlify.app` URL. Rename it under **Site configuration → Change site name**.

### Option B — GitHub + continuous deployment (recommended)

1. Push this project to a GitHub repo:
   ```bash
   git init
   git add .
   git commit -m "APEX RUSH v1"
   git branch -M main
   git remote add origin https://github.com/<you>/apex-rush.git
   git push -u origin main
   ```
2. In Netlify: **Add new site → Import an existing project → GitHub** → pick the repo.
3. Settings are auto-detected from `netlify.toml` (`npm run build` / `dist`). Click **Deploy**.
4. Every `git push` to `main` now redeploys automatically; pull requests get preview URLs.

### Option C — Netlify CLI

```bash
npm install -g netlify-cli
netlify login
npm run build
netlify deploy --prod --dir=dist
```

### Custom domain

**Site configuration → Domain management → Add a domain** — Netlify provisions a free HTTPS certificate automatically.

## Notes

- No SPA redirect rules needed: the game is a single page with no router.
- High scores are stored in each player's browser (`localStorage`) — per device, no backend required.
- Optional dev smoke test: `npm i -D playwright && npx playwright install chromium`, build, then `node scripts/smoke.mjs`.